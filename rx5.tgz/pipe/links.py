"""Blog cleanup: merge posts that compete with service pages (301), map every remaining
post to its service, add in-article CTAs and contextual internal links."""
import json, os, re
A = os.environ['APP'] + '/src/content'
SV = {s['slug']: s for s in json.load(open(f'{A}/services-index.json'))}

# Posts that target the same search intent as a service page: fold them into that page.
MERGE = {
    'abonamentno-pochistvane-na-ofisi-sofia': 'pochistvane-na-ofisi-sofia',
    'na-ofisi': 'pochistvane-na-ofisi-sofia',
    'zashto-da-izberem-abonamentno-pochistvane': 'abonamentno-pochistvane-na-ofisi',
    'abonamentno-pochistvane-na-domove-i-ofisi': 'abonamentno-pochistvane-na-domove',
    'abonamentno-pochistvane-na-vhodove': 'abonamentno-pochistvane-na-vhodove',
    'pochistvane-na-vhodove': 'abonamentno-pochistvane-na-vhodove',
    'pochistvane-sled-remont': 'pochistvane-sled-remont-sofia',
    'pochistvane-apartamenti-sofia-mashina': 'pochistvane-na-apartamenti-sofia',
    'pochistvane-apartamenti-usluga': 'pochistvane-na-apartamenti-sofia',
    'dogrami-i-profili': 'pochistvane-na-dograma',
    'pochistvane-na-shori': 'pochistvane-na-shtori',
    'meki-podovi-nastilki': 'prane-na-moket',
    'prane-moketi-domovete-kompleksna-usluga': 'prane-na-moket',
    'chistene-domove-ceni-profesionalna-firma': 'pochistvane-na-domove',
    'pochistvane-na-mebeli': 'prane-na-meka-mebel',
    'prane-na-oblicovki': 'prane-na-meka-mebel',
}
MERGE_PAGES = {'refleks-m': '/za-nas'}

RULES = [  # slug keyword -> primary service
    (r'divan', 'prane-na-divani-sofia'), (r'matrak', 'prane-na-matraci'), (r'kilim', 'prane-na-kilimi'),
    (r'moket', 'prane-na-moket'), (r'meka-mebel|kojeni|oblicov|prane-mebeli|izpirane|petna', 'prane-na-meka-mebel'),
    (r'mramor', 'pochistvane-na-mramor'), (r'mozaik', 'pochistvane-na-mozaika'), (r'terakot|plochki', 'pochistvane-na-terakot'),
    (r'laminat', 'pochistvane-na-laminat'), (r'dush|kotlen', 'pochistvane-na-dush-kabina'), (r'vani', 'pochistvane-na-vana'),
    (r'toaletna', 'pochistvane-na-toaletna-chinia'), (r'banya|muhal', 'pochistvane-na-banya'), (r'shtori', 'pochistvane-na-shtori'),
    (r'dograma', 'pochistvane-na-dograma'), (r'prozor', 'pochistvane-na-prozorci-sofia'), (r'apartament', 'pochistvane-na-apartamenti-sofia'),
    (r'remont', 'pochistvane-sled-remont-sofia'), (r'kashta', 'pochistvane-na-kashti'), (r'kompleksi', 'abonamentno-pochistvane-na-vhodove'),
    (r'magazin|trgovski', 'pochistvane-na-sgradi'), (r'abonament', 'abonamentno-pochistvane-na-ofisi'),
    (r'mebel|furnir|darv', 'pochistvane-na-domove'), (r'dom|osnovno|sezonno|proletno', 'pochistvane-na-domove'),
]
def service_for(slug):
    for rx, s in RULES:
        if re.search(rx, slug): return s
    return 'firma-za-pochistvane-sofia'

# phrase (regex, case-insensitive) -> service page; first hit per target is linked
PHRASES = [
    (r'пране(?:то)? на дивани', 'prane-na-divani-sofia'), (r'(?:пране|изпиране)(?:то)? на мека мебел', 'prane-na-meka-mebel'),
    (r'пране(?:то)? на матраци', 'prane-na-matraci'), (r'пране(?:то)? на килими', 'prane-na-kilimi'), (r'пране(?:то)? на мокет\w*', 'prane-na-moket'),
    (r'абонаментно почистване на офиси', 'abonamentno-pochistvane-na-ofisi'), (r'почистване(?:то)? на офиси', 'pochistvane-na-ofisi-sofia'),
    (r'почистване(?:то)? на (?:жилищни )?входове', 'abonamentno-pochistvane-na-vhodove'),
    (r'почистване(?:то)? след ремонт', 'pochistvane-sled-remont-sofia'), (r'почистване(?:то)? на апартамент\w*', 'pochistvane-na-apartamenti-sofia'),
    (r'(?:почистване|миене)(?:то)? на прозорци', 'pochistvane-na-prozorci-sofia'), (r'почистване(?:то)? на (?:стъкла|витрини)', 'pochistvane-na-stakla'),
    (r'почистване(?:то)? на (?:баня|бани)', 'pochistvane-na-banya'), (r'почистване(?:то)? на мрамор', 'pochistvane-na-mramor'),
    (r'почистване(?:то)? на мозайка', 'pochistvane-na-mozaika'), (r'почистване(?:то)? на теракот', 'pochistvane-na-terakot'),
    (r'почистване(?:то)? на гранитогрес', 'pochistvane-na-granitogres'), (r'почистване(?:то)? на ламинат', 'pochistvane-na-laminat'),
    (r'почистване(?:то)? на (?:\w+ )?дограма', 'pochistvane-na-dograma'), (r'почистване(?:то)? на щори', 'pochistvane-na-shtori'),
    (r'почистване(?:то)? на къщ[аи]', 'pochistvane-na-kashti'), (r'почистване(?:то)? на (?:домове|дома)', 'pochistvane-na-domove'),
    (r'почистване(?:то)? на сгради', 'pochistvane-na-sgradi'), (r'(?:Рейнбоу|Rainbow)', 'pochistvane-s-rainbow'),
    (r'фирм[аи] за почистване', 'firma-za-pochistvane-sofia'), (r'почистваща фирма', 'firma-za-pochistvane-sofia'),
]

def link_blocks(blocks, self_slug, max_links=4):
    used, n = set(), 0
    for b in blocks:
        if b['t'] != 'p' or n >= max_links: continue
        x = b['x']
        if '](' in x: continue
        for rx, target in PHRASES:
            if target in used or target == self_slug or n >= max_links: continue
            m = re.search(rx, x, flags=re.I)
            if not m: continue
            # never inside a **bold** span
            before = x[:m.start()]
            if before.count('**') % 2: continue
            x = x[:m.start()] + f'[{m.group(0)}](/uslugi/{target})' + x[m.end():]
            used.add(target); n += 1
            break  # one link per paragraph keeps the text readable
        b['x'] = x
    return n

def with_ctas(blocks, svc):
    cta = {'t': 'cta', 'slug': svc, 'name': SV[svc]['name']}
    blocks = [b for b in blocks if b['t'] != 'cta']
    heads = [i for i, b in enumerate(blocks) if b['t'] == 'h']
    mid = None
    if heads:
        target = len(blocks) * 0.45
        mid = min(heads, key=lambda i: abs(i - target))
        if mid < 2: mid = None
    if mid is None and len(blocks) > 6: mid = len(blocks) // 2
    out = blocks[:mid] + [cta] + blocks[mid:] if mid else list(blocks)
    out.append(dict(cta))
    return out

# --- posts
idx = json.load(open(f'{A}/posts-index.json'))
red = json.load(open(f'{A}/redirects.json'))
old_by_new = {}
for old, new in red.items():
    if new.startswith('/blog/'): old_by_new.setdefault(new[6:], []).append(old)
keep, links = [], 0
for p in idx:
    slug = p['slug']
    target = ('/uslugi/' + MERGE[slug]) if slug in MERGE else MERGE_PAGES.get(slug)
    if target:
        for old in old_by_new.get(slug, []): red[old] = target
        red[f'/blog/{slug}'] = target
        f = f'{A}/posts/{slug}.json'
        if os.path.exists(f): os.remove(f)
        continue
    svc = service_for(slug)
    post = json.load(open(f'{A}/posts/{slug}.json'))
    links += link_blocks(post['blocks'], None)
    post['blocks'] = with_ctas(post['blocks'], svc)
    post['svc'] = p['svc'] = svc
    json.dump(post, open(f'{A}/posts/{slug}.json', 'w'), ensure_ascii=False)
    keep.append(p)
json.dump(keep, open(f'{A}/posts-index.json', 'w'), ensure_ascii=False)
json.dump(red, open(f'{A}/redirects.json', 'w'), ensure_ascii=False, indent=0)

# --- services: cross-links to sibling services
slinks = 0
for s in SV:
    f = f'{A}/services/{s}.json'; d = json.load(open(f))
    slinks += link_blocks(d['blocks'], s, max_links=3)
    json.dump(d, open(f, 'w'), ensure_ascii=False)
print('posts kept', len(keep), 'merged', len(idx) - len(keep), 'links in posts', links, 'links in services', slinks, 'redirects', len(red))
