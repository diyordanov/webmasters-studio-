import { Fragment, useState, type ReactNode } from "react";

export type Img = { src: string; w: number; h: number; W: number; H: number; alt?: string };

export type Block =
  | { t: "h"; l: 2 | 3; x: string }
  | { t: "p"; x: string }
  | { t: "ul" | "ol"; i: string[] }
  | { t: "table"; r: string[][] }
  | ({ t: "img" } & Img)
  | { t: "faq"; i: { q: string; a: string }[] }
  | { t: "yt"; src: string }
  | { t: "cta"; slug: string; name: string };

const PHONE = /((?:\+359|0)[\d\s/-]{7,14}\d)/g;
const OUR_NUMBERS: Record<string, string> = { "877533703": "+359877533703", "28505588": "+35928505588" };

/** Bold markers, internal links ([text](/path)) and the company phone numbers as tap-to-call links. */
export function Rich({ x }: { x: string }) {
  const out: ReactNode[] = [];
  let k = 0;
  const phones = (t: string) =>
    t.split(PHONE).map((part, i) => {
      if (i % 2 === 0) return <Fragment key={k++}>{part}</Fragment>;
      const digits = part.replace(/\D/g, "");
      const hit = Object.keys(OUR_NUMBERS).find((n) => digits.endsWith(n));
      return hit ? (
        <a key={k++} className="rx-tel" href={`tel:${OUR_NUMBERS[hit]}`}>
          {part}
        </a>
      ) : (
        <Fragment key={k++}>{part}</Fragment>
      );
    });
  const bold = (t: string) =>
    t.split(/\*\*(.+?)\*\*/g).map((p, i) => (i % 2 ? <strong key={k++}>{phones(p)}</strong> : <Fragment key={k++}>{phones(p)}</Fragment>));
  const parts = x.split(/\[([^\]]+)\]\((\/[^)\s]*)\)/g);
  for (let i = 0; i < parts.length; i += 3) {
    out.push(...bold(parts[i]));
    if (i + 2 < parts.length) {
      out.push(
        <a key={k++} href={parts[i + 2]}>
          {parts[i + 1]}
        </a>,
      );
    }
  }
  return <>{out}</>;
}

export function plain(x: string) {
  return x.replace(/\*\*/g, "").replace(/\[([^\]]+)\]\([^)]*\)/g, "$1");
}

/** In-article call to action: the matching service plus the phone, so readers can act mid-article. */
function InlineCta({ slug, name }: { slug: string; name: string }) {
  return (
    <aside className="rx-icta" aria-label="Услуга">
      <p className="rx-icta__k">Рефлекс М · София</p>
      <p className="rx-icta__t">Нуждаете се от професионалисти? {name} с безплатен оглед.</p>
      <div className="rx-icta__a">
        <a className="rx-btn rx-btn--primary" href={`/uslugi/${slug}`}>
          {name}
          <span aria-hidden="true" className="rx-btn__arrow">
            →
          </span>
        </a>
        <a className="rx-btn rx-btn--line" href="tel:+359877533703">
          087 753 3703
        </a>
      </div>
    </aside>
  );
}

export function Picture({
  img,
  alt,
  sizes = "(max-width: 860px) 92vw, 720px",
  eager,
  className,
}: {
  img: Img;
  alt: string;
  sizes?: string;
  eager?: boolean;
  className?: string;
}) {
  return (
    <img
      className={className}
      src={`${img.src}-s.webp`}
      srcSet={`${img.src}-s.webp ${img.w}w, ${img.src}.webp ${img.W}w`}
      sizes={sizes}
      alt={alt}
      width={img.w}
      height={img.h}
      loading={eager ? "eager" : "lazy"}
      fetchPriority={eager ? "high" : undefined}
      decoding="async"
    />
  );
}

function YouTube({ src }: { src: string }) {
  const id = /embed\/([\w-]+)/.exec(src)?.[1];
  const [on, setOn] = useState(false);
  if (!id) return null;
  return (
    <div className="rx-video__frame rx-prose__video">
      {on ? (
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`}
          title="Видео от Рефлекс М"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"
          allowFullScreen
        />
      ) : (
        <button type="button" className="rx-video__play" onClick={() => setOn(true)} aria-label="Пусни видеото">
          <img src={`https://i.ytimg.com/vi/${id}/hqdefault.jpg`} alt="" loading="lazy" width={480} height={360} />
          <span className="rx-video__icon" aria-hidden="true" />
        </button>
      )}
    </div>
  );
}

/** Long-form content (service texts, articles, legal pages) from the content files. */
export function Prose({ blocks, title }: { blocks: Block[]; title: string }) {
  const out: ReactNode[] = [];
  blocks.forEach((b, i) => {
    switch (b.t) {
      case "h":
        out.push(b.l === 2 ? <h2 key={i}>{b.x}</h2> : <h3 key={i}>{b.x}</h3>);
        break;
      case "p":
        out.push(
          <p key={i}>
            <Rich x={b.x} />
          </p>,
        );
        break;
      case "ul":
      case "ol": {
        const L = b.t;
        out.push(
          <L key={i} className={L === "ul" ? "rx-ticks" : undefined}>
            {b.i.map((x, j) => (
              <li key={j}>
                <Rich x={x} />
              </li>
            ))}
          </L>,
        );
        break;
      }
      case "table":
        out.push(
          <div key={i} className="rx-table">
            <table>
              <tbody>
                {b.r.map((row, j) => (
                  <tr key={j}>
                    {row.map((c, k) => (
                      <td key={k}>
                        <Rich x={c} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>,
        );
        break;
      case "img":
        out.push(
          <figure key={i} className="rx-prose__fig">
            <Picture img={b} alt={b.alt || title} />
          </figure>,
        );
        break;
      case "faq":
        out.push(
          <div key={i} className="rx-prose__faq">
            {b.i.map((f) => (
              <details key={f.q} className="rx-qa">
                <summary>
                  <span className="rx-qa__q">{f.q}</span>
                  <span className="rx-qa__icon" aria-hidden="true" />
                </summary>
                <p>{f.a}</p>
              </details>
            ))}
          </div>,
        );
        break;
      case "yt":
        out.push(<YouTube key={i} src={b.src} />);
        break;
      case "cta":
        out.push(<InlineCta key={i} slug={b.slug} name={b.name} />);
        break;
    }
  });
  return <div className="rx-prose">{out}</div>;
}

export function faqOf(blocks: Block[]) {
  return blocks.flatMap((b) => (b.t === "faq" ? b.i : []));
}
