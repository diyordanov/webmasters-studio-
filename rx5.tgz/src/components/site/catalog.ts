import type { Block, Img } from "./prose";
import servicesIndex from "../../content/services-index.json";
import postsIndex from "../../content/posts-index.json";

export type ServiceCard = { slug: string; name: string; group: string; img: Img | null; excerpt: string };
export type Service = ServiceCard & { desc: string; intro: string; blocks: Block[] };
export type PostCard = { slug: string; title: string; date: string; cat: string; img: Img | null; excerpt: string; svc?: string };
export type Post = PostCard & { desc: string; blocks: Block[] };

export const SERVICES_INDEX = servicesIndex as ServiceCard[];
export const POSTS_INDEX = postsIndex as PostCard[];

export const GROUPS: { id: string; title: string; text: string }[] = [
  { id: "main", title: "Основни услуги", text: "Най-търсените услуги на Рефлекс М в София." },
  { id: "home", title: "Домове и сгради", text: "Основно и абонаментно почистване на жилища, къщи и сгради." },
  { id: "wash", title: "Пране на мека мебел и настилки", text: "Машинно екстракторно пране на мебели, матраци, килими и мокет." },
  { id: "glass", title: "Стъкла, дограми и щори", text: "Миене на прозорци, витрини, стъклени фасади, дограма и щори." },
  { id: "bath", title: "Бани и санитария", text: "Хигиенизиране на бани, вани, душ кабини и тоалетни." },
  { id: "floor", title: "Подови настилки", text: "Машинно почистване, измиване и полиране на твърди настилки." },
];

export const serviceHref = (slug: string) => `/uslugi/${slug}`;
export const postHref = (slug: string) => `/blog/${slug}`;

export function relatedServices(slug: string, group: string, n = 3) {
  const same = SERVICES_INDEX.filter((s) => s.group === group && s.slug !== slug);
  const main = SERVICES_INDEX.filter((s) => s.group === "main" && s.slug !== slug);
  return [...same, ...main].filter((s, i, a) => a.findIndex((x) => x.slug === s.slug) === i).slice(0, n);
}

const MONTHS = ["януари", "февруари", "март", "април", "май", "юни", "юли", "август", "септември", "октомври", "ноември", "декември"];
export function bgDate(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return `${d} ${MONTHS[m - 1]} ${y} г.`;
}
