/**
 * The Reflex M film: four real-feeling jobs, each scrubbed from "before" to
 * "after". Scene 1 carries the page H1, scenes 2–4 the three main H2 services.
 * Every poster is the exact first frame of the encoded clip beside it.
 *
 * Keep this array a module constant. Changing its identity on every render
 * intentionally rebuilds the media controller.
 */
import { createElement } from "react";

import type {
  ScrollScrubScene,
  ScrollScrubTheme,
} from "@/components/scroll-scrub/scroll-scrub";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#F2760E",
  background: "#0B0B0C",
  ink: "#FFFFFF",
  muted: "#C9C9CC",
};

function cta(href: string, label: string, phone = false) {
  return createElement(
    "div",
    { className: "rx-ch-actions" },
    createElement("a", { className: "rx-btn rx-btn--primary", href }, label, createElement("span", { "aria-hidden": "true", className: "rx-btn__arrow" }, "→")),
    phone
      ? createElement("a", { className: "rx-btn rx-btn--ghost", href: "tel:+359877533703" }, "087 753 3703")
      : null,
  );
}

export const scrollScrubScenes: ScrollScrubScene[] = [
  {
    id: "firma-za-pochistvane",
    label: "Фирма за почистване",
    kicker: "Рефлекс М · професионално почистване",
    title: "Фирма за почистване София",
    body: "Рефлекс М е фирма за професионално почистване в София — офиси, домове, входове и обекти след ремонт. Безплатен оглед и оферта с крайна цена.",
    tags: ["4.6 ★ · 126 отзива в Google", "Цяла София", "Безплатен оглед"],
    actions: cta("/uslugi/firma-za-pochistvane-sofia", "Фирма за почистване София", true),
    clip: "/assets/world/rx-01.mp4",
    poster: "/assets/world/rx-01-poster.webp",
    align: "right",
    objectPosition: "38% 50%",
    scroll: 1.6,
  },
  {
    id: "pochistvane-na-ofisi",
    label: "Офиси",
    kicker: "Офиси и бизнес сгради",
    title: "Почистване на офиси София",
    body: "Еднократно или по абонамент — почистваме работни места, кухни, санитарни помещения и общи части по график, съобразен с работното ви време.",
    tags: ["Еднократно или абонаментно", "Професионални препарати"],
    actions: cta("/uslugi/pochistvane-na-ofisi-sofia", "Почистване на офиси в София"),
    clip: "/assets/world/rx-02.mp4",
    poster: "/assets/world/rx-02-poster.webp",
    align: "right",
    scroll: 1.5,
  },
  {
    id: "pochistvane-na-apartamenti",
    label: "Апартаменти",
    kicker: "Домове и апартаменти",
    title: "Почистване на апартаменти София",
    body: "Основно почистване на апартаменти и къщи — от кухнята и баните до подовете, с машинно пране на дивани, матраци и мека мебел.",
    tags: ["Основно почистване", "Пране на мека мебел"],
    actions: cta("/uslugi/pochistvane-na-apartamenti-sofia", "Почистване на апартаменти в София"),
    clip: "/assets/world/rx-03.mp4",
    poster: "/assets/world/rx-03-poster.webp",
    align: "right",
    scroll: 1.5,
  },
  {
    id: "pochistvane-sled-remont",
    label: "След ремонт",
    kicker: "След ремонт и строителство",
    title: "Почистване след ремонт София",
    body: "Премахваме строителния прах, фолиата, петната от боя и фугиращи смеси, за да влезете в чист дом или офис веднага след ремонта.",
    tags: ["Строителен прах", "Фолиа и петна от боя"],
    actions: cta("/uslugi/pochistvane-sled-remont-sofia", "Почистване след ремонт в София"),
    clip: "/assets/world/rx-04.mp4",
    poster: "/assets/world/rx-04-poster.webp",
    align: "left",
    scroll: 1.5,
  },
];
