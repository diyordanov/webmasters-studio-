import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";

import { ScrollScrub } from "@/components/scroll-scrub/scroll-scrub";
import { SiteFooter, SiteHeader } from "@/components/site/chrome";
import { BUSINESS_LD, OG_IMAGE, SITE_URL } from "@/components/site/data";
import { MobileJourney } from "@/components/site/mobile-journey";
import { Areas, ClientsStrip, Contact, Faq, MoreServices, Prices, Process, Reviews } from "@/components/site/sections";
import { scrollScrubScenes, scrollScrubTheme } from "@/scroll-scrub-scenes";

const TITLE = "Рефлекс М – почистваща фирма в София";
const DESCRIPTION =
  "Фирма за почистване в София: офиси, апартаменти, входове и обекти след ремонт, пране на дивани и миене на прозорци. Безплатен оглед. ☎ 087 753 3703";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { name: "robots", content: "index, follow, max-image-preview:large" },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:url", content: `${SITE_URL}/` },
      { property: "og:locale", content: "bg_BG" },
      { property: "og:site_name", content: "Рефлекс М" },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: OG_IMAGE },
    ],
    links: [
      { rel: "canonical", href: `${SITE_URL}/` },
      { rel: "preload", href: "/assets/world/rx-01-poster.webp", as: "image", type: "image/webp", media: "(min-width: 861px)" },
      { rel: "preload", href: "/assets/world/m/f-001.webp", as: "image", type: "image/webp", media: "(max-width: 860px)" },
    ],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(BUSINESS_LD) }],
  }),
  component: Index,
});

/** Desktop scrubs the 2K film; phones get the pinned frame sequence (no video seeking). */
function Hero() {
  const [mobile, setMobile] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 860px)");
    const sync = () => setMobile(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);
  return (
    <div id="nachalo" className="rx-hero">
      {mobile ? null : (
        <div className="rx-desk">
          <ScrollScrub scenes={scrollScrubScenes} theme={scrollScrubTheme} />
        </div>
      )}
      <MobileJourney scenes={scrollScrubScenes} enabled={mobile} />
    </div>
  );
}

function Index() {
  return (
    <div className="rx">
      <a className="rx-skip" href="#uslugi">
        Към съдържанието
      </a>
      <SiteHeader />
      <main>
        <Hero />
        <ClientsStrip />
        <MoreServices />
        <Process />
        <Prices />
        <Reviews />
        <Areas />
        <Faq />
        <Contact />
      </main>
      <SiteFooter />
    </div>
  );
}
