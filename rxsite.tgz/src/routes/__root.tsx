import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import "../components/site/site.css";
import { reportHiggsfieldError } from "../lib/higgsfield-error-reporting";
// Page metadata read at BUILD time (feed card + defaults for pages without their own head).
import appMetaJson from "../app-meta.json";

declare const __HF_DESIGN_INSPECTOR__: boolean;

const DEFAULT_TITLE = "Рефлекс М – почистваща фирма в София";
const DEFAULT_DESCRIPTION =
  "Фирма за почистване в София: офиси, апартаменти, входове и обекти след ремонт. Безплатен оглед. ☎ 087 753 3703";

type AppMeta = {
  og_title?: string | null;
  og_description?: string | null;
  og_image_url?: string | null;
  favicon_url?: string | null;
  og_video_url?: string | null;
  marketplace_cover_url?: string | null;
};

const appMeta = appMetaJson as AppMeta;

function buildHead(meta: AppMeta) {
  const title = meta.og_title ?? DEFAULT_TITLE;
  const description = meta.og_description ?? DEFAULT_DESCRIPTION;
  return {
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title },
      { name: "description", content: description },
      { name: "author", content: "Рефлекс М ООД" },
      { name: "theme-color", content: "#FFFFFF" },
      { name: "format-detection", content: "telephone=no" },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "preload", href: "/assets/fonts/onest-cyrillic.woff2", as: "font", type: "font/woff2", crossOrigin: "anonymous" as const },
      { rel: "stylesheet", href: appCss },
      { rel: "icon", type: "image/svg+xml", href: "/assets/brand/favicon.svg" },
      { rel: "icon", type: "image/png", sizes: "32x32", href: "/assets/brand/favicon-32.png" },
      { rel: "apple-touch-icon", sizes: "180x180", href: "/assets/brand/apple-touch-icon.png" },
    ],
  };
}

function NotFoundComponent() {
  return (
    <div className="rx-plain">
      <p className="rx-plain__code">404</p>
      <h1>Страницата не е намерена</h1>
      <p>Възможно е адресът да е сменен. Вижте началната страница или се обадете на 087 753 3703.</p>
      <a className="rx-btn rx-btn--primary" href="/">
        Към началната страница
      </a>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportHiggsfieldError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="rx-plain">
      <h1>Страницата не се зареди</h1>
      <p>Опитайте отново или се обадете на 087 753 3703.</p>
      <button
        className="rx-btn rx-btn--primary"
        type="button"
        onClick={() => {
          router.invalidate();
          reset();
        }}
      >
        Опитай отново
      </button>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => buildHead(appMeta),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="bg" style={{ colorScheme: "light" }}>
      <head>
        <HeadContent />
      </head>
      <body className="rx-body">
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  useEffect(() => {
    if (!__HF_DESIGN_INSPECTOR__) {
      return;
    }

    void import("../module/design-inspector/runtime")
      .then(({ installHiggsfieldDesignInspector }) => {
        installHiggsfieldDesignInspector();
      })
      .catch((error) => {
        reportHiggsfieldError(
          error instanceof Error ? error : new Error("Failed to load design inspector"),
          { boundary: "higgsfield_design_inspector_import" },
        );
      });
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
