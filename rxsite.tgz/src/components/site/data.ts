/** Production origin. Canonical and og:url point here; the preview host is not indexed. */
export const SITE_URL = "https://reflex-m.com";
export const OG_IMAGE = `${SITE_URL}/assets/brand/og-home.jpg`;

export const BRAND = "Рефлекс М";
export const LEGAL_NAME = "Рефлекс М ООД";
export const EIK = "202117837";
export const EMAIL = "office@reflex-m.com";
export const PHONE_MOBILE = { label: "087 753 3703", href: "tel:+359877533703" };
export const PHONE_OFFICE = { label: "02 850 55 88", href: "tel:+35928505588" };
export const ADDRESS = {
  street: "ул. Чаталджа 20, партер, офис 1",
  postal: "1527",
  city: "София",
  full: "ул. Чаталджа 20, партер, офис 1, 1527 София",
};
export const GOOGLE_REVIEWS_URL = "https://share.google/VC4WLeVMAL52Xvtzu";
export const RATING = { value: "4.6", count: 126 };
export const MAP_EMBED =
  "https://www.google.com/maps?q=%D1%83%D0%BB.+%D0%A7%D0%B0%D1%82%D0%B0%D0%BB%D0%B4%D0%B6%D0%B0+20,+1527+%D0%A1%D0%BE%D1%84%D0%B8%D1%8F&z=15&output=embed";

/** Every service lives under /uslugi/<slug>. Order = importance on the home page. */
export const SERVICES = {
  firma: { href: "/uslugi/firma-za-pochistvane-sofia", name: "Фирма за почистване София" },
  ofisi: { href: "/uslugi/pochistvane-na-ofisi-sofia", name: "Почистване на офиси София" },
  apartamenti: { href: "/uslugi/pochistvane-na-apartamenti-sofia", name: "Почистване на апартаменти София" },
  remont: { href: "/uslugi/pochistvane-sled-remont-sofia", name: "Почистване след ремонт София" },
  divani: { href: "/uslugi/prane-na-divani-sofia", name: "Пране на дивани София" },
  prozorci: { href: "/uslugi/pochistvane-na-prozorci-sofia", name: "Фирма за почистване на прозорци София" },
  abonamentOfisi: { href: "/uslugi/abonamentno-pochistvane-na-ofisi", name: "Абонаментно почистване на офиси" },
  vhodove: { href: "/uslugi/abonamentno-pochistvane-na-vhodove", name: "Абонаментно почистване на жилищни входове" },
} as const;

export const MORE_SERVICES = [
  {
    ...SERVICES.divani,
    img: "/assets/img/divani",
    w: 700,
    h: 394,
    big: 1400,
    alt: "Служител на Рефлекс М пере светъл диван с екстракторна машина",
    text: "Машинно пране с екстракция на дивани, фотьойли, матраци и столове. Изваждаме дълбоката мръсотия, петната и миризмите от тъканта.",
    points: ["Дивани и ъглови гарнитури", "Матраци и столове", "Килими и мокет"],
  },
  {
    ...SERVICES.prozorci,
    img: "/assets/img/prozorci",
    w: 700,
    h: 465,
    big: 1400,
    alt: "Промишлен алпинист на Рефлекс М мие стъклена фасада на височина",
    text: "Двустранно миене на прозорци, витрини и стъклени фасади — включително на височина, с промишлени алпинисти.",
    points: ["Прозорци и витрини", "Стъклени фасади", "Работа на височина"],
  },
  {
    ...SERVICES.abonamentOfisi,
    img: "/assets/img/ofisi",
    w: 700,
    h: 394,
    big: 1400,
    alt: "Екипът на Рефлекс М почиства офис с работни места",
    text: "Постоянна чистота в офиса по график, съобразен с работното ви време — ежедневно, седмично или в избрани дни.",
    points: ["Работни места и кухни", "Санитарни помещения", "Общи части"],
  },
  {
    ...SERVICES.vhodove,
    img: "/assets/img/vhodove",
    w: 600,
    h: 1067,
    big: 900,
    alt: "Служител на Рефлекс М мие стълбище в жилищен вход",
    text: "Редовно почистване на стълбища, площадки, асансьори и входни врати за етажната собственост.",
    points: ["Стълбища и площадки", "Асансьори и врати", "Редовен график"],
  },
] as const;

export const CLIENTS = [
  { name: "Deutsche Bank", src: "/assets/clients/deutsche.png", w: 400, h: 96 },
  { name: "OMV", src: "/assets/clients/omv.png", w: 150, h: 96 },
  { name: "DHL", src: "/assets/clients/dhl.png", w: 435, h: 96 },
  { name: "SDI", src: "/assets/clients/sdi.png", w: 222, h: 96 },
  { name: "Groupama", src: "/assets/clients/groupama.png", w: 402, h: 96 },
  { name: "Sodexo", src: "/assets/clients/sodexo.png", w: 267, h: 96 },
] as const;

export const STEPS = [
  { t: "Запитване", d: "Обадете се на 087 753 3703 или ни пишете през формата — питаме за обекта, площта и какво трябва да се почисти." },
  { t: "Безплатен оглед", d: "Идваме на място, преценяваме техниката и препаратите и ви даваме оферта с крайна цена." },
  { t: "Почистване", d: "Нашият екип идва в уговорения ден и час с професионални машини и препарати за всяка повърхност." },
  { t: "Предаване", d: "Обхождаме обекта с вас. При абонамент поддържаме същото ниво на чистота при всяко посещение." },
] as const;

export const PRICE_FACTORS = [
  { t: "Вид и площ на обекта", d: "Офис, апартамент, вход или обект след ремонт — и колко квадратни метра са." },
  { t: "Степен на замърсяване", d: "Поддържащото почистване отнема по-малко време от основното или след ремонт." },
  { t: "Обхват на услугата", d: "Прозорци, пране на мека мебел, машинно почистване на подове — само това, което ви трябва." },
  { t: "Честота", d: "При абонамент цената се договаря на месец според броя посещения." },
] as const;

export const AREAS = [
  "Център", "Лозенец", "Изток", "Изгрев", "Младост", "Студентски град", "Дружба", "Слатина",
  "Гео Милев", "Подуяне", "Хаджи Димитър", "Оборище", "Красно село", "Хиподрума", "Бели брези",
  "Борово", "Манастирски ливади", "Овча купел", "Люлин", "Надежда", "Сердика", "Банишора",
  "Витоша", "Бояна", "Драгалевци", "Симеоново", "Бъкстон", "Кръстова вада",
] as const;

export const FAQ = [
  {
    q: "Колко струва почистването?",
    a: "Цената зависи от вида и площта на обекта, степента на замърсяване, обхвата на услугата и честотата при абонамент. След безплатен оглед получавате оферта с крайна цена.",
  },
  {
    q: "Безплатен ли е огледът?",
    a: "Да. Първоначалният оглед на офис или дом е безплатен. На него преценяваме нужната техника и препарати и ви даваме точна оферта.",
  },
  {
    q: "В кои квартали на София работите?",
    a: "Рефлекс М почиства в цяла София — от Център и Лозенец до Младост, Люлин, Надежда, Бояна и Драгалевци.",
  },
  {
    q: "С какви препарати и техника работите?",
    a: "Работим с професионална техника и препарати, подбрани според повърхността — камък, ламинат, текстил, стъкло или неръждаема стомана.",
  },
  {
    q: "Предлагате ли абонаментно почистване?",
    a: "Да. Предлагаме абонаментно почистване на офиси и на жилищни входове по график, който договаряме с вас — ежедневно, седмично или в избрани дни.",
  },
  {
    q: "Как да заявя почистване?",
    a: "Обадете се на 087 753 3703 или 02 850 55 88, пишете на office@reflex-m.com или изпратете запитване през формата на тази страница.",
  },
] as const;

export const BUSINESS_LD = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "LocalBusiness",
      "@id": `${SITE_URL}/#business`,
      name: BRAND,
      alternateName: ["Reflex M", "Reflex - M", "Рефлекс М ООД"],
      legalName: LEGAL_NAME,
      taxID: EIK,
      description:
        "Рефлекс М е фирма за професионално почистване в София — почистване на офиси, апартаменти, входове и обекти след ремонт, пране на дивани и миене на прозорци.",
      url: `${SITE_URL}/`,
      logo: `${SITE_URL}/assets/brand/logo-dark.png`,
      image: OG_IMAGE,
      telephone: "+359877533703",
      email: EMAIL,
      address: {
        "@type": "PostalAddress",
        streetAddress: ADDRESS.street,
        postalCode: ADDRESS.postal,
        addressLocality: ADDRESS.city,
        addressCountry: "BG",
      },
      areaServed: { "@type": "City", name: "София" },
      contactPoint: [
        { "@type": "ContactPoint", telephone: "+359877533703", contactType: "customer service", areaServed: "BG", availableLanguage: "bg" },
        { "@type": "ContactPoint", telephone: "+35928505588", contactType: "customer service", areaServed: "BG", availableLanguage: "bg" },
      ],
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Услуги по почистване в София",
        itemListElement: Object.values(SERVICES).map((s) => ({
          "@type": "Offer",
          itemOffered: { "@type": "Service", name: s.name, url: `${SITE_URL}${s.href}` },
        })),
      },
    },
    {
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
      name: BRAND,
      url: `${SITE_URL}/`,
      inLanguage: "bg",
      publisher: { "@id": `${SITE_URL}/#business` },
    },
    {
      "@type": "FAQPage",
      "@id": `${SITE_URL}/#faq`,
      mainEntity: FAQ.map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    },
  ],
};
