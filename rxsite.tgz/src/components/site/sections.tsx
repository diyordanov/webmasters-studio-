import { useEffect, useRef, useState, type FormEvent } from "react";

import { PhoneIcon } from "./chrome";
import {
  ADDRESS,
  AREAS,
  BRAND,
  CLIENTS,
  EMAIL,
  FAQ,
  GOOGLE_REVIEWS_URL,
  MAP_EMBED,
  MORE_SERVICES,
  PHONE_MOBILE,
  PHONE_OFFICE,
  PRICE_FACTORS,
  RATING,
  SERVICES,
  STEPS,
} from "./data";

/** Adds `is-in` once an element scrolls into view — drives the squeegee-wipe reveals. */
function useReveal<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const items = Array.from(el.querySelectorAll<HTMLElement>("[data-wipe]"));
    if (!("IntersectionObserver" in window)) {
      items.forEach((i) => i.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-in");
            io.unobserve(e.target);
          }
        });
      },
      { rootMargin: "0px 0px -12% 0px", threshold: 0.2 },
    );
    items.forEach((i) => io.observe(i));
    return () => io.disconnect();
  }, []);
  return ref;
}

export function ClientsStrip() {
  return (
    <section className="rx-clients" aria-labelledby="rx-clients-h">
      <div className="rx-wrap rx-clients__inner">
        <h2 id="rx-clients-h" className="rx-clients__h">
          Почистваме за
        </h2>
        <ul className="rx-clients__list">
          {CLIENTS.map((c) => (
            <li key={c.name}>
              <img src={c.src} alt={c.name} width={c.w} height={c.h} loading="lazy" decoding="async" />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function MoreServices() {
  const ref = useReveal<HTMLElement>();
  return (
    <section className="rx-section rx-services" id="uslugi" ref={ref} aria-labelledby="rx-services-h">
      <div className="rx-wrap">
        <div className="rx-head">
          <p className="rx-eyebrow">Услуги</p>
          <h2 id="rx-services-h" className="rx-h2">
            Още услуги в София
          </h2>
          <p className="rx-lead">
            Освен офиси, апартаменти и обекти след ремонт, {BRAND} пере мека мебел, мие прозорци и поддържа офиси и
            жилищни входове по абонамент.
          </p>
        </div>
        <div className="rx-services__grid">
          {MORE_SERVICES.map((s, i) => (
            <article className="rx-card" key={s.href}>
              <div className="rx-card__media" data-wipe="">
                <img
                  src={`${s.img}-s.webp`}
                  srcSet={`${s.img}-s.webp ${s.w}w, ${s.img}.webp ${s.big}w`}
                  sizes="(max-width: 760px) 92vw, (max-width: 1200px) 46vw, 600px"
                  alt={s.alt}
                  loading="lazy"
                  decoding="async"
                  width={s.w}
                  height={s.h}
                />
              </div>
              <div className="rx-card__body">
                <span className="rx-card__num">0{i + 1}</span>
                <h3 className="rx-h3">{s.name}</h3>
                <p>{s.text}</p>
                <ul className="rx-card__points">
                  {s.points.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
                <a className="rx-card__link" href={s.href}>
                  Към услугата „{s.name}“<span aria-hidden="true">→</span>
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Process() {
  return (
    <section className="rx-section rx-dark" id="kak-rabotim" aria-labelledby="rx-process-h">
      <div className="rx-wrap">
        <div className="rx-head">
          <p className="rx-eyebrow">Как работим</p>
          <h2 id="rx-process-h" className="rx-h2">
            Как протича почистването с {BRAND}
          </h2>
          <p className="rx-lead">Четири стъпки от обаждането до чистия обект — без изненади в цената.</p>
        </div>
        <ol className="rx-steps">
          {STEPS.map((s, i) => (
            <li key={s.t} className="rx-step">
              <span className="rx-step__n">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="rx-h3">{s.t}</h3>
              <p>{s.d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function Prices() {
  return (
    <section className="rx-section rx-prices" id="ceni" aria-labelledby="rx-prices-h">
      <div className="rx-wrap rx-prices__grid">
        <div className="rx-prices__intro">
          <p className="rx-eyebrow">Цени</p>
          <h2 id="rx-prices-h" className="rx-h2">
            Колко струва почистването в София
          </h2>
          <p className="rx-lead">
            Всеки обект е различен, затова не работим с „средни“ цени. След безплатен оглед получавате оферта с крайна
            цена, която не се променя в деня на почистването.
          </p>
          <div className="rx-prices__cta">
            <a className="rx-btn rx-btn--primary" href="#kontakti">
              Заявете безплатен оглед<span aria-hidden="true" className="rx-btn__arrow">→</span>
            </a>
            <a className="rx-btn rx-btn--line" href={PHONE_MOBILE.href}>
              <PhoneIcon /> {PHONE_MOBILE.label}
            </a>
          </div>
        </div>
        <ul className="rx-factors">
          {PRICE_FACTORS.map((f, i) => (
            <li key={f.t} className="rx-factor">
              <span className="rx-factor__i">{String.fromCharCode(65 + i)}</span>
              <div>
                <h3 className="rx-h3">{f.t}</h3>
                <p>{f.d}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function Reviews() {
  const ref = useReveal<HTMLElement>();
  return (
    <section className="rx-section rx-reviews" id="otzivi" ref={ref} aria-labelledby="rx-reviews-h">
      <div className="rx-wrap rx-reviews__grid">
        <div className="rx-reviews__score">
          <p className="rx-eyebrow">Отзиви</p>
          <h2 id="rx-reviews-h" className="rx-h2">
            Отзиви за {BRAND} в Google
          </h2>
          <div className="rx-score">
            <span className="rx-score__v">{RATING.value}</span>
            <div>
              <span className="rx-stars rx-stars--lg" aria-hidden="true">
                ★★★★★
              </span>
              <p>
                Средна оценка от <strong>{RATING.count} отзива</strong> в Google
              </p>
            </div>
          </div>
          <p className="rx-lead">
            Оценките идват от клиенти, които са ползвали услугите ни за офис, дом или вход. Прочетете ги директно в
            профила ни в Google.
          </p>
          <a className="rx-btn rx-btn--dark" href={GOOGLE_REVIEWS_URL} target="_blank" rel="noopener noreferrer">
            Прочетете отзивите в Google<span aria-hidden="true" className="rx-btn__arrow">↗</span>
          </a>
        </div>
        <figure className="rx-team" data-wipe="">
          <img
            src="/assets/img/team-s.webp"
            srcSet="/assets/img/team-s.webp 700w, /assets/img/team.webp 1400w"
            sizes="(max-width: 900px) 92vw, 640px"
            alt="Екипът на Рефлекс М в черни тениски с логото на фирмата"
            width={700}
            height={465}
            loading="lazy"
            decoding="async"
          />
          <figcaption>Екипът на {BRAND} — професионално обучени служители, които познават всеки тип повърхност.</figcaption>
        </figure>
      </div>
    </section>
  );
}

export function Areas() {
  return (
    <section className="rx-section rx-areas" id="kvartali" aria-labelledby="rx-areas-h">
      <div className="rx-wrap rx-areas__grid">
        <div>
          <p className="rx-eyebrow">Райони</p>
          <h2 id="rx-areas-h" className="rx-h2">
            Почистване във всички квартали на София
          </h2>
          <p className="rx-lead">
            Офисът ни е на {ADDRESS.street}, {ADDRESS.city}. Екипите ни почистват офиси, домове и входове в цяла София.
          </p>
          <ul className="rx-areas__list">
            {AREAS.map((a) => (
              <li key={a}>{a}</li>
            ))}
          </ul>
        </div>
        <MapEmbed />
      </div>
    </section>
  );
}

/** The Google map only loads once the visitor gets near it — it is heavy and never needed above the fold. */
function MapEmbed() {
  const ref = useRef<HTMLDivElement>(null);
  const [show, setShow] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) {
      setShow(true);
      return;
    }
    const io = new IntersectionObserver(
      (e) => {
        if (e[0]?.isIntersecting) {
          setShow(true);
          io.disconnect();
        }
      },
      { rootMargin: "400px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div className="rx-map" ref={ref}>
      {show ? (
        <iframe
          title={`Карта: ${BRAND}, ${ADDRESS.full}`}
          src={MAP_EMBED}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      ) : null}
      <div className="rx-map__pin">
        <strong>{BRAND}</strong>
        <span>{ADDRESS.full}</span>
      </div>
    </div>
  );
}

export function Faq() {
  return (
    <section className="rx-section rx-faq" id="vaprosi" aria-labelledby="rx-faq-h">
      <div className="rx-wrap rx-faq__grid">
        <div>
          <p className="rx-eyebrow">Въпроси</p>
          <h2 id="rx-faq-h" className="rx-h2">
            Често задавани въпроси за почистването
          </h2>
        </div>
        <div className="rx-faq__list">
          {FAQ.map((f, i) => (
            <details key={f.q} className="rx-qa" open={i === 0}>
              <summary>
                <h3 className="rx-qa__q">{f.q}</h3>
                <span className="rx-qa__icon" aria-hidden="true" />
              </summary>
              <p>{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

const SERVICE_OPTIONS = [
  SERVICES.ofisi.name,
  SERVICES.apartamenti.name,
  SERVICES.remont.name,
  SERVICES.divani.name,
  "Миене на прозорци",
  SERVICES.abonamentOfisi.name,
  SERVICES.vhodove.name,
  "Друго",
];

export function Contact() {
  const [sent, setSent] = useState(false);

  // The request opens the visitor's e-mail app with everything filled in, addressed to the office.
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const get = (k: string) => String(f.get(k) ?? "").trim();
    const body = [
      `Име: ${get("name")}`,
      `Телефон: ${get("phone")}`,
      `Услуга: ${get("service")}`,
      `Адрес / квартал: ${get("area")}`,
      "",
      get("message"),
    ].join("\n");
    const subject = `Запитване за оглед — ${get("service")}`;
    window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setSent(true);
  };

  return (
    <section className="rx-section rx-contact" id="kontakti" aria-labelledby="rx-contact-h">
      <div className="rx-wrap rx-contact__grid">
        <div className="rx-contact__info">
          <p className="rx-eyebrow">Контакти</p>
          <h2 id="rx-contact-h" className="rx-h2">
            Заявете безплатен оглед
          </h2>
          <p className="rx-lead">
            Обадете се или изпратете запитване — ще се свържем с вас, за да уговорим оглед и да ви дадем оферта.
          </p>
          <address className="rx-nap">
            <a className="rx-nap__phone" href={PHONE_MOBILE.href}>
              <PhoneIcon /> {PHONE_MOBILE.label}
            </a>
            <a className="rx-nap__phone" href={PHONE_OFFICE.href}>
              <PhoneIcon /> {PHONE_OFFICE.label}
            </a>
            <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
            <span>
              {BRAND}, {ADDRESS.full}
            </span>
          </address>
        </div>
        <form className="rx-form" onSubmit={onSubmit} aria-describedby="rx-form-note">
          <div className="rx-field">
            <label htmlFor="rx-name">Име</label>
            <input id="rx-name" name="name" autoComplete="name" required />
          </div>
          <div className="rx-field">
            <label htmlFor="rx-phone">Телефон</label>
            <input id="rx-phone" name="phone" type="tel" autoComplete="tel" inputMode="tel" required />
          </div>
          <div className="rx-field">
            <label htmlFor="rx-service">Услуга</label>
            <select id="rx-service" name="service" defaultValue={SERVICE_OPTIONS[0]}>
              {SERVICE_OPTIONS.map((o) => (
                <option key={o}>{o}</option>
              ))}
            </select>
          </div>
          <div className="rx-field">
            <label htmlFor="rx-area">Адрес или квартал</label>
            <input id="rx-area" name="area" autoComplete="street-address" />
          </div>
          <div className="rx-field rx-field--wide">
            <label htmlFor="rx-message">Какво трябва да почистим?</label>
            <textarea id="rx-message" name="message" rows={4} />
          </div>
          <button className="rx-btn rx-btn--primary rx-field--wide" type="submit">
            Изпрати запитване<span aria-hidden="true" className="rx-btn__arrow">→</span>
          </button>
          <p id="rx-form-note" className="rx-form__note" role="status">
            {sent
              ? `Отворихме имейла ви с готовото запитване до ${EMAIL}. Ако не се е отворил, обадете се на ${PHONE_MOBILE.label}.`
              : `Запитването се изпраща до ${EMAIL}. Отговаряме в работно време.`}
          </p>
        </form>
      </div>
    </section>
  );
}
