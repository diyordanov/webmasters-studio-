import { useEffect, useState } from "react";

import { ADDRESS, BRAND, EIK, EMAIL, GOOGLE_REVIEWS_URL, LEGAL_NAME, PHONE_MOBILE, PHONE_OFFICE, SERVICES } from "./data";

const NAV = [
  { href: "#uslugi", label: "Услуги" },
  { href: "#kak-rabotim", label: "Как работим" },
  { href: "#ceni", label: "Цени" },
  { href: "#otzivi", label: "Отзиви" },
  { href: "#kontakti", label: "Контакти" },
] as const;

export function SiteHeader() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("rx-lock", open);
  }, [open]);

  return (
    <header className={`rx-header${solid ? " is-solid" : ""}${open ? " is-open" : ""}`}>
      <div className="rx-header__bar">
        <a className="rx-header__logo" href="/" aria-label={`${BRAND} — начало`}>
          <img src="/assets/brand/logo-dark.png" alt={`${BRAND} лого`} width={560} height={222} />
        </a>
        <nav className="rx-header__nav" aria-label="Основна навигация">
          {NAV.map((n) => (
            <a key={n.href} href={n.href}>
              {n.label}
            </a>
          ))}
        </nav>
        <div className="rx-header__cta">
          <a className="rx-header__phone" href={PHONE_MOBILE.href}>
            <PhoneIcon />
            <span>{PHONE_MOBILE.label}</span>
          </a>
          <a className="rx-btn rx-btn--primary rx-btn--sm" href="#kontakti">
            Безплатен оглед
          </a>
        </div>
        <button
          className="rx-header__toggle"
          type="button"
          aria-expanded={open}
          aria-controls="rx-mobile-nav"
          aria-label={open ? "Затвори менюто" : "Отвори менюто"}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
          <span />
        </button>
      </div>
      <div className="rx-header__sheet" id="rx-mobile-nav" hidden={!open}>
        <nav aria-label="Мобилна навигация">
          {NAV.map((n) => (
            <a key={n.href} href={n.href} onClick={() => setOpen(false)}>
              {n.label}
            </a>
          ))}
        </nav>
        <a className="rx-btn rx-btn--primary" href={PHONE_MOBILE.href}>
          Обадете се: {PHONE_MOBILE.label}
        </a>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const year = 2026;
  return (
    <footer className="rx-footer">
      <div className="rx-wrap rx-footer__grid">
        <div className="rx-footer__brand">
          <img src="/assets/brand/logo-white.png" alt={`${BRAND} лого`} width={560} height={222} loading="lazy" />
          <p>Професионално почистване на офиси, домове и входове в София.</p>
          <a className="rx-footer__rating" href={GOOGLE_REVIEWS_URL} target="_blank" rel="noopener noreferrer">
            <span className="rx-stars" aria-hidden="true">★★★★★</span> 4.6 от 126 отзива в Google
          </a>
        </div>
        <div>
          <p className="rx-footer__h">Основни услуги</p>
          <ul>
            {[SERVICES.firma, SERVICES.ofisi, SERVICES.apartamenti, SERVICES.remont].map((s) => (
              <li key={s.href}>
                <a href={s.href}>{s.name}</a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="rx-footer__h">Още услуги</p>
          <ul>
            {[SERVICES.divani, SERVICES.prozorci, SERVICES.abonamentOfisi, SERVICES.vhodove].map((s) => (
              <li key={s.href}>
                <a href={s.href}>{s.name}</a>
              </li>
            ))}
          </ul>
        </div>
        <address className="rx-footer__nap">
          <p className="rx-footer__h">Контакти</p>
          <span>{BRAND}</span>
          <span>{ADDRESS.full}</span>
          <a href={PHONE_MOBILE.href}>{PHONE_MOBILE.label}</a>
          <a href={PHONE_OFFICE.href}>{PHONE_OFFICE.label}</a>
          <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
        </address>
      </div>
      <div className="rx-wrap rx-footer__legal">
        <span>
          © {year} {LEGAL_NAME}, ЕИК {EIK}
        </span>
        <span>Фирма за почистване в София</span>
      </div>
    </footer>
  );
}

export function PhoneIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false">
      <path
        fill="currentColor"
        d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z"
      />
    </svg>
  );
}
