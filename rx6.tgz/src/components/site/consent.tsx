import { useEffect, useState, useSyncExternalStore } from "react";

/**
 * Cookie consent. The site sets no analytics or advertising cookies. The only
 * third parties are Google Maps and YouTube, which load only after consent
 * (or, for a video, when the visitor presses play). The choice is stored in
 * the visitor's browser (localStorage), never sent to a server.
 */
const KEY = "rx-consent-v1";
type Choice = "all" | "necessary";
const listeners = new Set<() => void>();
let reopen = false;

function read(): Choice | null {
  try {
    const v = window.localStorage.getItem(KEY);
    return v === "all" || v === "necessary" ? v : null;
  } catch {
    return null;
  }
}
function emit() {
  listeners.forEach((l) => l());
}
export function setConsent(c: Choice) {
  try {
    window.localStorage.setItem(KEY, c);
  } catch {
    /* private mode: the choice lasts for this page view */
  }
  reopen = false;
  memo = c;
  emit();
}
export function openConsent() {
  reopen = true;
  emit();
}
let memo: Choice | null | undefined;
function snapshot() {
  if (memo === undefined) memo = read();
  return `${memo ?? "none"}|${reopen ? 1 : 0}`;
}
function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

/** "all" | "necessary" | null (not decided yet). Always null during SSR. */
export function useConsent() {
  const s = useSyncExternalStore(subscribe, snapshot, () => "ssr|0");
  const [c, open] = s.split("|");
  return { choice: c === "all" || c === "necessary" ? (c as Choice) : null, ready: c !== "ssr", reopened: open === "1" };
}

export function CookieBanner() {
  const { choice, ready, reopened } = useConsent();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted || !ready || (choice && !reopened)) return null;
  return (
    <div className="rx-cookie" role="dialog" aria-labelledby="rx-cookie-t" aria-describedby="rx-cookie-d">
      <p id="rx-cookie-t" className="rx-cookie__t">
        Бисквитки и външно съдържание
      </p>
      <p id="rx-cookie-d" className="rx-cookie__d">
        Сайтът използва само необходимите за работата си технологии. С „Приемам всички“ разрешавате и картата на Google Maps
        и видеата от YouTube, които могат да записват бисквитки. Повече в{" "}
        <a href="/politika-za-biskvitki">Политиката за бисквитки</a> и{" "}
        <a href="/politika-za-poveritelnost">Политиката за поверителност</a>.
      </p>
      <div className="rx-cookie__a">
        <button type="button" className="rx-btn rx-btn--line rx-btn--sm" onClick={() => setConsent("necessary")}>
          Само необходимите
        </button>
        <button type="button" className="rx-btn rx-btn--primary rx-btn--sm" onClick={() => setConsent("all")}>
          Приемам всички
        </button>
      </div>
    </div>
  );
}
