import { useEffect, useState } from "react";

const VIBER = "viber://chat?number=%2B359877533703";

/** Floating contact button: call either number or write in Viber. */
export function ContactFab() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);
  return (
    <div className={`rx-fab${open ? " is-open" : ""}`}>
      <ul className="rx-fab__menu" id="rx-fab-menu" hidden={!open}>
        <li>
          <a className="rx-fab__item" href="tel:+359877533703">
            <span className="rx-fab__ico rx-fab__ico--call" aria-hidden="true">
              <PhoneGlyph />
            </span>
            <span>
              <small>Мобилен</small>087 753 3703
            </span>
          </a>
        </li>
        <li>
          <a className="rx-fab__item" href="tel:+35928505588">
            <span className="rx-fab__ico rx-fab__ico--call" aria-hidden="true">
              <PhoneGlyph />
            </span>
            <span>
              <small>Офис</small>02 850 55 88
            </span>
          </a>
        </li>
        <li>
          <a className="rx-fab__item" href={VIBER}>
            <span className="rx-fab__ico rx-fab__ico--viber" aria-hidden="true">
              <ViberGlyph />
            </span>
            <span>
              <small>Пишете ни във</small>Viber
            </span>
          </a>
        </li>
      </ul>
      <button
        type="button"
        className="rx-fab__btn"
        aria-expanded={open}
        aria-controls="rx-fab-menu"
        aria-label={open ? "Затвори контактите" : "Обадете се или пишете във Viber"}
        onClick={() => setOpen((v) => !v)}
      >
        {open ? <span className="rx-fab__x" aria-hidden="true" /> : <PhoneGlyph />}
        <span className="rx-fab__pulse" aria-hidden="true" />
      </button>
    </div>
  );
}

function PhoneGlyph() {
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">
      <path
        fill="currentColor"
        d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z"
      />
    </svg>
  );
}

function ViberGlyph() {
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">
      <path
        fill="currentColor"
        d="M11.4 2c-2.9.1-5.4.6-7 2.1C3.2 5.4 2.6 7.6 2.5 10.4c-.1 2.8-.1 8 4.9 9.4v2.2s0 .9.6 1.1c.7.2 1.1-.5 1.8-1.2l1.3-1.4c3.5.3 6.2-.4 6.5-.5.7-.2 4.7-.7 5.3-5.8.7-5.3-.3-8.6-2.1-10.1-.5-.5-2.7-2.1-7.7-2.1h-1zm.5 1.6h.9c4.3 0 6.1 1.3 6.5 1.7 1.5 1.3 2.3 4.2 1.7 8.7-.5 4.1-3.5 4.4-4.1 4.6-.2.1-2.6.7-5.6.5 0 0-2.2 2.7-2.9 3.4-.1.1-.2.2-.3.1-.1 0-.2-.2-.2-.4v-3.8c-4.2-1.2-4-5.6-3.9-8 .1-2.3.5-4.2 1.8-5.4 1.4-1.2 3.7-1.4 6.1-1.4zm.3 2.3a.3.3 0 0 0 0 .6c1.3 0 2.3.4 3.1 1.2.8.8 1.2 1.9 1.2 3.4a.3.3 0 1 0 .6 0c0-1.6-.5-2.9-1.4-3.8-.9-.9-2.1-1.4-3.5-1.4zm-3.4.7c-.3 0-.5 0-.8.3l-.6.6c-.6.7-.4 1.5-.1 2.2a14 14 0 0 0 5.9 6.1c.7.3 1.4.4 2-.2l.6-.7c.3-.3.3-.7 0-1l-1.4-1.1c-.4-.3-.9-.2-1.2.1l-.5.5c-.2.2-.5.2-.5.2-1.9-.5-2.6-2.5-2.6-2.5s0-.3.2-.5l.5-.4c.3-.3.4-.8.1-1.2l-1-1.4c-.2-.2-.4-.3-.6-.3zm3.6.5a.3.3 0 0 0 0 .6c.8.1 1.3.3 1.7.7.4.4.6 1 .6 1.8a.3.3 0 1 0 .6 0c0-.9-.3-1.7-.8-2.2-.5-.5-1.2-.8-2.1-.9zm.3 1.5a.3.3 0 0 0 0 .6c.6 0 .9.3.9.9a.3.3 0 1 0 .6 0c0-.9-.6-1.5-1.5-1.5z"
      />
    </svg>
  );
}
