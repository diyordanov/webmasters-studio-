import { createFileRoute } from "@tanstack/react-router";

import { openConsent } from "@/components/site/consent";
import { ADDRESS, EIK, EMAIL, LEGAL_NAME, PHONE_MOBILE } from "@/components/site/data";
import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";

const PATH = "/politika-za-biskvitki";
const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "Политика за бисквитки", href: PATH },
];

export const Route = createFileRoute("/politika-za-biskvitki")({
  head: () => {
    const h = pageHead({
      title: "Политика за бисквитки | Рефлекс М",
      description: "Какви бисквитки и подобни технологии използва сайтът на Рефлекс М ООД и как да управлявате избора си.",
      path: PATH,
      schema: [crumbsLd(CRUMBS)],
    });
    h.meta = h.meta.map((m) => ("name" in m && m.name === "robots" ? { name: "robots", content: "index, nofollow" } : m));
    return h;
  },
  component: CookiePolicy,
});

function CookiePolicy() {
  return (
    <PageShell>
      <PageHead crumbs={CRUMBS} title="Политика за бисквитки" lead="В сила от 4 октомври 2026 г." />
      <section className="rx-wrap rx-prose-wrap rx-legal">
        <div className="rx-prose">
          <h2>Кой отговаря за сайта</h2>
          <p>
            {LEGAL_NAME}, ЕИК {EIK}, със седалище и адрес {ADDRESS.full}. Имейл: <a href={`mailto:${EMAIL}`}>{EMAIL}</a>, телефон:{" "}
            <a href={PHONE_MOBILE.href}>{PHONE_MOBILE.label}</a>.
          </p>
          <h2>Какво представляват бисквитките</h2>
          <p>
            Бисквитките са малки текстови файлове, които уебсайтът или вградено в него съдържание запазва във вашия браузър.
            Подобни технологии, като локалното хранилище на браузъра (localStorage), работят по същия начин.
          </p>
          <h2>Какво използва този сайт</h2>
          <h3>Необходими</h3>
          <p>
            Сайтът не използва бисквитки за анализ, реклама или проследяване. Единственото, което запазваме във вашия браузър, е
            изборът ви в прозореца за бисквитки (запис „rx-consent-v1“ в локалното хранилище), за да не ви питаме при всяко
            посещение. Този запис не се изпраща към нас и не съдържа лични данни.
          </p>
          <h3>Външно съдържание (само с ваше съгласие)</h3>
          <ul className="rx-ticks">
            <li>
              <strong>Google Maps</strong> — картата с адреса ни. Зарежда се едва след като изберете „Приемам всички“ или натиснете
              „Покажи картата“. Google може да запише свои бисквитки според{" "}
              <a href="https://policies.google.com/technologies/cookies" target="_blank" rel="noopener noreferrer">
                политиката на Google
              </a>
              .
            </li>
            <li>
              <strong>YouTube</strong> — видеата с отзиви на клиенти. Плейърът се зарежда от домейна youtube-nocookie.com и
              само когато натиснете бутона за пускане на видеото.
            </li>
          </ul>
          <h2>Как да промените избора си</h2>
          <p>
            Можете да промените избора си по всяко време от бутона по-долу или от връзката „Настройки за бисквитки“ във
            футъра. Можете и да изтриете бисквитките и данните на сайта от настройките на браузъра си.
          </p>
          <p>
            <button type="button" className="rx-btn rx-btn--line" onClick={openConsent}>
              Настройки за бисквитки
            </button>
          </p>
          <h2>Лични данни</h2>
          <p>
            Как обработваме лични данни, например при запитване по телефон или имейл, е описано в{" "}
            <a href="/politika-za-poveritelnost">Политиката за поверителност</a>.
          </p>
        </div>
      </section>
      <CtaBand />
    </PageShell>
  );
}
