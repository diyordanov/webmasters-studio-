import os
APP = os.environ['APP']
def edit(p, pairs):
    p = f'{APP}/{p}'; s = open(p).read()
    for a, b in pairs:
        if a not in s: raise SystemExit(f'patch miss in {p}: {a[:70]}')
        s = s.replace(a, b, 1)
    open(p, 'w').write(s)

edit('src/routes/__root.tsx', [
    ('import { THEME_COLOR } from "../components/site/data";',
     'import { THEME_COLOR } from "../components/site/data";\nimport { CookieBanner } from "../components/site/consent";\nimport { ContactFab } from "../components/site/contact-fab";'),
    ('      <Outlet />\n', '      <Outlet />\n      <ContactFab />\n      <CookieBanner />\n'),
])
edit('src/components/site/areas.tsx', [
    ('import { useEffect, useRef, useState } from "react";', 'import { useEffect, useRef, useState } from "react";\n\nimport { useConsent } from "./consent";'),
    ('  const [show, setShow] = useState(false);\n', '  const [show, setShow] = useState(false);\n  const { choice } = useConsent();\n  const [allow, setAllow] = useState(false);\n  const ok = choice === "all" || allow;\n'),
    ('      {show ? (\n        <iframe', '      {show && ok ? (\n        <iframe'),
    ('      ) : null}\n      <div className="rx-map__pin">', '''      ) : (
        <div className="rx-map__consent">
          <span>Картата се зарежда от Google Maps и може да запише бисквитки.</span>
          <button type="button" className="rx-btn rx-btn--line rx-btn--sm" onClick={() => setAllow(true)}>
            Покажи картата
          </button>
        </div>
      )}
      <div className="rx-map__pin">'''),
])
edit('src/components/site/chrome.tsx', [
    ('import { useEffect, useState } from "react";', 'import { useEffect, useState } from "react";\n\nimport { openConsent } from "./consent";'),
    ('          <a href="/politika-za-poveritelnost">Политика за поверителност</a>\n',
     '          <a href="/politika-za-poveritelnost">Политика за поверителност</a>\n          <a href="/politika-za-biskvitki">Политика за бисквитки</a>\n          <button type="button" onClick={openConsent}>\n            Настройки за бисквитки\n          </button>\n'),
])
edit('src/components/site/sections.tsx', [
    (': `Запитването се изпраща до ${EMAIL}. Отговаряме в работно време.`}',
     ''': (
                  <>
                    Запитването се изпраща до {EMAIL}. Данните от него използваме само за да ви отговорим — вижте{" "}
                    <a href="/politika-za-poveritelnost">Политиката за поверителност</a>.
                  </>
                )}'''),
])
edit('src/routes/sitemap[.]xml.ts', [
    ('  { path: "/politika-za-poveritelnost", priority: "0.2", freq: "yearly" },',
     '  { path: "/politika-za-poveritelnost", priority: "0.2", freq: "yearly" },\n  { path: "/politika-za-biskvitki", priority: "0.2", freq: "yearly" },'),
])
css = f'{APP}/src/components/site/site.css'
s = open(css).read()
if 'floating contact' not in s:
    open(css, 'w').write(s + open('/home/user/rx6/fab.css').read())
print('patched')
