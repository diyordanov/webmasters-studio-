import { useEffect, useRef, useState } from "react";

import { ADDRESS, AREAS, BRAND, MAP_EMBED, PHONE_MOBILE } from "./data";

const HALF = Math.ceil(AREAS.length / 2);
const ROW_A = AREAS.slice(0, HALF);
const ROW_B = AREAS.slice(HALF);

/** One endlessly sliding row. The list is rendered twice so the loop has no seam; the copy is hidden from screen readers. */
function Marquee({ items, reverse }: { items: readonly string[]; reverse?: boolean }) {
  return (
    <div className={`rx-marquee${reverse ? " rx-marquee--rev" : ""}`}>
      <div className="rx-marquee__track">
        <ul className="rx-marquee__list">
          {items.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
        <ul className="rx-marquee__list" aria-hidden="true">
          {items.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function Areas() {
  return (
    <section className="rx-section rx-areas" id="kvartali" aria-labelledby="rx-areas-h">
      <div className="rx-wrap rx-areas__grid">
        <div className="rx-areas__text">
          <p className="rx-eyebrow">Райони</p>
          <h2 id="rx-areas-h" className="rx-h2">
            Почистване във всички квартали на София
          </h2>
          <p className="rx-lead">
            {BRAND} почиства офиси, апартаменти, къщи и жилищни входове в цяла София. Офисът ни е на {ADDRESS.street},
            а екипите ни тръгват към обектите с техниката и препаратите, нужни за конкретната задача.
          </p>
          <p className="rx-areas__p">
            Работим както в централните части — Център, Оборище, Лозенец и Изток, — така и в големите жилищни комплекси
            като Младост, Люлин, Дружба, Надежда и Овча купел. Почистваме и къщи в полите на Витоша — Бояна, Драгалевци,
            Симеоново и Кръстова вада.
          </p>
          <p className="rx-areas__p">
            За абонаментно почистване на офис или вход съставяме график, съобразен с района и работното ви време. Не
            виждате квартала си в списъка? Обадете се на <a href={PHONE_MOBILE.href}>{PHONE_MOBILE.label}</a> — най-вероятно
            работим и там.
          </p>
        </div>
        <MapEmbed />
      </div>
      <div className="rx-areas__rows" aria-label="Квартали, в които почистваме">
        <Marquee items={ROW_A} />
        <Marquee items={ROW_B} reverse />
      </div>
    </section>
  );
}

/** The Google map only loads once the visitor gets near it — it is heavy and never needed above the fold. */
function MapEmbed() {
  const ref = useRef<HTMLDivElement>(null);
  const [show, setShow] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) {
      setShow(true);
      return;
    }
    const io = new IntersectionObserver(
      (e) => {
        if (e[0]?.isIntersecting) {
          setShow(true);
          io.disconnect();
        }
      },
      { rootMargin: "400px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div className="rx-map" ref={ref}>
      {show ? (
        <iframe
          title={`Карта: ${BRAND}, ${ADDRESS.full}`}
          src={MAP_EMBED}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      ) : null}
      <div className="rx-map__pin">
        <strong>{BRAND}</strong>
        <span>{ADDRESS.full}</span>
      </div>
    </div>
  );
}
