import { useCallback, useEffect, useRef, useState } from "react";

import { ALL_SERVICES, BRAND } from "./data";

/** All eight services in a swipeable rail: native scroll-snap, arrow buttons and a progress bar. */
export function ServicesSlider() {
  const railRef = useRef<HTMLUListElement>(null);
  const [edge, setEdge] = useState({ start: true, end: false, p: 0 });

  const sync = useCallback(() => {
    const el = railRef.current;
    if (!el) return;
    const max = el.scrollWidth - el.clientWidth;
    setEdge({ start: el.scrollLeft <= 4, end: el.scrollLeft >= max - 4, p: max > 0 ? el.scrollLeft / max : 0 });
  }, []);

  useEffect(() => {
    const el = railRef.current;
    if (!el) return;
    sync();
    el.addEventListener("scroll", sync, { passive: true });
    window.addEventListener("resize", sync);
    return () => {
      el.removeEventListener("scroll", sync);
      window.removeEventListener("resize", sync);
    };
  }, [sync]);

  const step = (dir: 1 | -1) => {
    const el = railRef.current;
    if (!el) return;
    const card = el.querySelector<HTMLElement>("li");
    const w = card ? card.offsetWidth + 24 : el.clientWidth * 0.8;
    el.scrollBy({ left: dir * w, behavior: "smooth" });
  };

  return (
    <section className="rx-section rx-services" id="uslugi" aria-labelledby="rx-services-h">
      <div className="rx-wrap rx-services__top">
        <div className="rx-head">
          <p className="rx-eyebrow">Услуги</p>
          <h2 id="rx-services-h" className="rx-h2">
            Още услуги в София
          </h2>
          <p className="rx-lead">
            Всички услуги на {BRAND} на едно място — от еднократно почистване на офис или апартамент до абонаментна
            поддръжка на входове и пране на мека мебел.
          </p>
        </div>
        <div className="rx-slider__nav">
          <button type="button" className="rx-slider__btn" onClick={() => step(-1)} disabled={edge.start} aria-label="Предишна услуга">
            ←
          </button>
          <button type="button" className="rx-slider__btn" onClick={() => step(1)} disabled={edge.end} aria-label="Следваща услуга">
            →
          </button>
        </div>
      </div>
      <ul className="rx-slider" ref={railRef} aria-label="Услуги на Рефлекс М">
        {ALL_SERVICES.map((s, i) => (
          <li key={s.href} className="rx-slide">
            <article className="rx-card">
              <div className="rx-card__media">
                <img
                  src={`${s.img}-s.webp`}
                  srcSet={`${s.img}-s.webp ${s.w}w, ${s.img}.webp ${s.big}w`}
                  sizes="(max-width: 760px) 84vw, 420px"
                  alt={s.alt}
                  loading="lazy"
                  decoding="async"
                  width={s.w}
                  height={s.h}
                />
              </div>
              <div className="rx-card__body">
                <span className="rx-card__num">{String(i + 1).padStart(2, "0")} / {String(ALL_SERVICES.length).padStart(2, "0")}</span>
                <h3 className="rx-h3">{s.name}</h3>
                <p>{s.text}</p>
                <a className="rx-card__link" href={s.href}>
                  {s.cta}
                  <span aria-hidden="true">→</span>
                </a>
              </div>
            </article>
          </li>
        ))}
      </ul>
      <div className="rx-wrap">
        <div className="rx-slider__bar" aria-hidden="true">
          <span style={{ transform: `scaleX(${Math.max(0.08, edge.p)})` }} />
        </div>
      </div>
    </section>
  );
}
