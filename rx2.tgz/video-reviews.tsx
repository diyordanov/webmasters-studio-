import { useState } from "react";

import { BRAND } from "./data";

const VIDEOS = [
  { id: "tcitudd1clM", client: "Содексо", title: "Рефлекс М клиенти — Содексо" },
  { id: "65oI7sV7-Q0", client: "Вали Компютърс", title: "Рефлекс М клиенти — Вали Компютърс" },
  { id: "ufLEPiyc10g", client: "Дом на киното", title: "Рефлекс М клиенти — Дом на киното" },
] as const;

/**
 * Client video stories from the company's YouTube channel. Only a local poster
 * loads with the page; the YouTube player (privacy-enhanced domain) loads when
 * the visitor presses play.
 */
export function VideoReviews() {
  const [playing, setPlaying] = useState<string | null>(null);
  return (
    <div className="rx-videos">
      <div className="rx-videos__head">
        <h3 className="rx-h3">Клиентите на {BRAND} разказват</h3>
        <a className="rx-videos__channel" href="https://www.youtube.com/@Reflex-m" target="_blank" rel="noopener noreferrer">
          Всички видеа в YouTube <span aria-hidden="true">↗</span>
        </a>
      </div>
      <ul className="rx-videos__grid">
        {VIDEOS.map((v) => (
          <li key={v.id} className="rx-video">
            <div className="rx-video__frame">
              {playing === v.id ? (
                <iframe
                  src={`https://www.youtube-nocookie.com/embed/${v.id}?autoplay=1&rel=0&modestbranding=1`}
                  title={v.title}
                  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                  allowFullScreen
                />
              ) : (
                <button type="button" className="rx-video__play" onClick={() => setPlaying(v.id)} aria-label={`Пусни видеото: ${v.title}`}>
                  <img src={`/assets/video/${v.id}.webp`} alt="" width={960} height={540} loading="lazy" decoding="async" />
                  <span className="rx-video__icon" aria-hidden="true" />
                </button>
              )}
            </div>
            <p className="rx-video__cap">
              <span>Клиент</span> {v.client}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}
