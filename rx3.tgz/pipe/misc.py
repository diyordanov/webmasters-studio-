import re, urllib.request, json
def get(u): return urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'}), timeout=40).read().decode('utf8', 'ignore')
out = {}
for u in ['https://reflex-m.com/za-nas/', 'https://reflex-m.com/galeriq/', 'https://reflex-m.com/za-nas/mediite-za-nas/', 'https://reflex-m.com/za-nas/nashite-klienti/']:
    h = get(u)
    body = h[h.find('</header>'):h.find('<footer')]
    imgs = list(dict.fromkeys(re.findall(r'(?:href|src|data-src)="(https://reflex-m.com/wp-content/uploads/[^"]+\.(?:jpe?g|png|webp|gif))"', body)))
    out[u] = {'imgs': imgs, 'yt': list(dict.fromkeys(re.findall(r'youtube\.com/embed/([\w-]+)', body)))}
json.dump(out, open('site/misc.json', 'w'))
print({k: (len(v['imgs']), len(v['yt'])) for k, v in out.items()})
