import json, re, copy
P = json.load(open('site/pages.json')); Q = json.load(open('site/posts.json'))
posts_meta = {p['link']: p for p in json.load(open('posts.json'))}
cats = {c['id']: c['name'] for c in json.load(open('cats.json'))}
BASE = 'https://reflex-m.com'
BOIL = re.compile(r'Пишете ни|office@reflex-m\.com$|keyboard_arrow|mail_outline|^\*\*$|^Начало$')

def clean(blocks, h1=''):
    blocks = copy.deepcopy(blocks)
    out = []
    for b in blocks:
        if b['t'] == 'p':
            x = b['x'].replace('Рефрлекс', 'Рефлекс').strip()
            if BOIL.search(x) or len(x) < 3: continue
            if h1 and x.replace('**', '').strip() == h1: continue
            plain = x.replace('**', '')
            if not re.search(r'[a-zа-я]', plain) and len(plain) < 70: continue
            if re.search(r'ТУК МОЖЕ|Обадете се:|Имейл:|Телефон:|^Получете (индивидуална оферта|цена)|^Заявете безплатен оглед$', plain): continue
            fq = re.match(r'\*\*(.+?\?)\*\*\s*(.+)', x)
            if fq:
                item = {'q': fq.group(1).strip(), 'a': fq.group(2).strip()}
                if out and out[-1]['t'] == 'faq': out[-1]['i'].append(item)
                else: out.append({'t': 'faq', 'i': [item]})
                continue
            m = re.fullmatch(r'\*\*(.+?)\*\*[:.]?', x)
            if m and len(m.group(1)) <= 140 and (not out or out[-1]['t'] != 'h'):
                out.append({'t': 'h', 'l': 2, 'x': m.group(1).strip().rstrip(':')}); continue
            if x.startswith('✓') or x.startswith('▪'):
                items = [i.strip() for i in re.split(r'[✓▪]', x) if i.strip()]
                if out and out[-1]['t'] == 'ul' and out[-1].get('chk'): out[-1]['i'] += items
                else: out.append({'t': 'ul', 'i': items, 'chk': True})
                continue
            out.append({'t': 'p', 'x': x})
        elif b['t'] == 'h':
            if h1 and b['x'] == h1: continue
            if b['x'] == 'Свържете се с нас': continue
            out.append(b)
        else:
            out.append(b)
    res, run = [], []
    def flush():
        if len(run) >= 3: res.append({'t': 'ul', 'i': [r['x'] for r in run]})
        else: res.extend(run)
        run.clear()
    for b in out:
        if b['t'] == 'p' and len(b['x']) < 90 and not re.search(r'[.!?:]$', b['x'].replace('**', '').strip()):
            run.append(b); continue
        flush(); res.append(b)
    flush(); out = res
    while out and out[-1]['t'] == 'h': out.pop()
    for b in out: b.pop('chk', None)
    return out

IMG = {}
def img(src, base):
    src = re.sub(r'-\d+x\d+(\.\w+)$', r'\1', src)
    if src not in IMG: IMG[src] = base
    return IMG[src]

def first_p(bl):
    for b in bl:
        if b['t'] == 'p' and len(b['x']) > 60: return b
    return None

def mk_desc(t):
    t = re.sub(r'\*\*', '', t)
    return (t[:152].rsplit(' ', 1)[0] + '…') if len(t) > 155 else t

S = [
 ('firma-za-pochistvane-sofia','Фирма за почистване София',['/uslugi-za-pochistvane/chastni-klienti/'],None,'main'),
 ('pochistvane-na-ofisi-sofia','Почистване на офиси София',['/uslugi-za-pochistvane/korporativni-klienti/pochistvane-na-ofisi/','/profesionalno-pochistvane/abonamentno-pochistvane-na-ofisi/'],['/abonamentno-pochistvane-ofisi/'],'main'),
 ('pochistvane-na-apartamenti-sofia','Почистване на апартаменти София',['/pochistvane-apartament-sofia-ceni/'],None,'main'),
 ('pochistvane-sled-remont-sofia','Почистване след ремонт София',['/pochistvane-sled-remont/'],None,'main'),
 ('prane-na-divani-sofia','Пране на дивани София',['/pochistvane-i-prane-na-divani-sofia/'],None,'main'),
 ('pochistvane-na-prozorci-sofia','Фирма за почистване на прозорци София',['/pochistvane-miene-prozorci-sofia/'],None,'main'),
 ('abonamentno-pochistvane-na-ofisi','Абонаментно почистване на офиси',['/abonamentno-pochistvane-ofisi/','/uslugi-za-pochistvane/korporativni-klienti/'],['/uslugi-za-pochistvane/korporativni-klienti/','POST:/profesionalno-pochistvane/zashto-da-izberem-abonamentno-pochistvane/'],'main'),
 ('abonamentno-pochistvane-na-vhodove','Абонаментно почистване на жилищни входове',['/uslugi-za-pochistvane/chastni-klienti/abonamentno-pochistvane-na-vhodove/'],None,'main'),
 ('pochistvane-na-domove','Почистване на домове',['/uslugi-za-pochistvane/chastni-klienti/profesionalno-pochistvane-na-domove-sofia-ceni/'],None,'home'),
 ('abonamentno-pochistvane-na-domove','Абонаментно почистване на домове',['/abonamentno-pochistvane-domove/'],None,'home'),
 ('pochistvane-na-kashti','Почистване на къщи',['/pochistvane-kashti/'],None,'home'),
 ('pochistvane-na-sgradi','Почистване на сгради',['/pochistvane-na-sgradi/'],None,'home'),
 ('prane-na-meka-mebel','Пране на мека мебел',['/prane-na-meka-mebel/'],None,'wash'),
 ('prane-na-matraci','Пране на матраци',['/prane-na-matraci/'],None,'wash'),
 ('prane-na-kilimi','Пране на килими',['/prane-na-kilimi/'],None,'wash'),
 ('prane-na-moket','Пране на мокет',['/prane-na-moket/'],None,'wash'),
 ('pochistvane-s-rainbow','Почистване с Рейнбоу прахосмукачка',['/pochistvane-s-reinbou/'],None,'wash'),
 ('pochistvane-na-stakla','Почистване и миене на стъкла',['/pochistvane-na-stykla-sled-remont/'],None,'glass'),
 ('pochistvane-na-dograma','Почистване на дограма',['/pochistvane-pvc-dograma-remont/'],None,'glass'),
 ('pochistvane-na-shtori','Почистване и пране на щори',['/pochistvane-na-shtori/'],None,'glass'),
 ('pochistvane-na-banya','Почистване на баня',['/pochistvane-banya/'],None,'bath'),
 ('pochistvane-na-vana','Почистване на вана',['/pochistvane-vana/'],None,'bath'),
 ('pochistvane-na-dush-kabina','Почистване на душ кабина',['/pochistvane-dush-kabina/'],None,'bath'),
 ('pochistvane-na-toaletna','Почистване на тоалетна',['/pochistvane-toaletna/'],None,'bath'),
 ('pochistvane-na-toaletna-chinia','Почистване на тоалетна чиния',['/pochistvane-toaletna-chinia/'],None,'bath'),
 ('pochistvane-na-mramor','Почистване на мрамор',['/pochistvane-mramor/'],None,'floor'),
 ('pochistvane-na-granitogres','Почистване на гранитогрес',['/pochistvane-granitogres/'],None,'floor'),
 ('pochistvane-na-mozaika','Почистване на мозайка',['/pochistvane-mozaika-cena/'],None,'floor'),
 ('pochistvane-na-terakot','Почистване на теракот',['/pochistvane-terakot/'],None,'floor'),
 ('pochistvane-na-laminat','Почистване на ламинат',['/pochistvane-laminat/'],None,'floor'),
]
U = 'https://reflex-m.com/wp-content/uploads/'
FALLBACK_IMG = {
 'firma-za-pochistvane-sofia': U+'2020/04/20171006_095621-1-scaled.jpg',
 'pochistvane-na-ofisi-sofia': U+'2020/04/20170723_1715441-scaled.jpg',
 'abonamentno-pochistvane-na-ofisi': U+'2020/04/img_20190914_092544-scaled.jpg',
 'prane-na-divani-sofia': U+'2020/04/img_20200424_110512_burst1-1-scaled.jpg',
 'pochistvane-na-prozorci-sofia': U+'2020/04/dsc_0129_kor-scaled.jpg',
 'abonamentno-pochistvane-na-vhodove': U+'2020/05/img_20200430_090907-scaled.jpg',
 'pochistvane-na-vana': U+'2020/04/dsc_0179-scaled.jpg',
 'pochistvane-na-granitogres': U+'2020/04/dsc_0814-scaled.jpg',
 'pochistvane-na-terakot': U+'2020/04/dsc_0818-scaled.jpg',
 'pochistvane-na-laminat': U+'2020/04/dsc_0112-scaled.jpg',
}
SKIP_POSTS = {'/profesionalno-pochistvane/abonamentno-pochistvane-na-ofisi/'}  # same text as the office service page

services = []; redirects = {}
for slug, name, olds, srcs, group in S:
    srcs = srcs or olds; bl = []; meta = None
    for s in srcs:
        d = Q[BASE + s[5:]] if s.startswith('POST:') else P[BASE + s]
        meta = meta or d
        bl += clean(d['blocks'], d['h1'][0] if d['h1'] else '')
    imgs = [b for b in bl if b['t'] == 'img']
    hero = FALLBACK_IMG.get(slug) or (imgs[0]['src'] if imgs else None)
    bl = [b for b in bl if not (b['t'] == 'img' and b['src'] == hero)]
    for b in bl:
        if b['t'] == 'img': b['src'] = img(b['src'], f'c/{slug}-{len(IMG)}')
    fp = first_p(bl); intro = fp['x'] if fp else ''
    if fp: bl.remove(fp)
    services.append({'slug': slug, 'name': name, 'group': group, 'img': img(hero, f'c/{slug}') if hero else None,
                     'intro': intro, 'desc': meta['desc'] or mk_desc(intro), 'blocks': bl})
    for o in olds: redirects[o] = f'/uslugi/{slug}'

posts = []
for u, d in Q.items():
    path = u.replace(BASE, '')
    if path in SKIP_POSTS: continue
    m = posts_meta[u]; slug = path.strip('/').split('/')[-1]
    bl = clean(d['blocks'], d['h1'][0] if d['h1'] else '')
    imgs = [b for b in bl if b['t'] == 'img']; hero = imgs[0]['src'] if imgs else None
    bl = [b for b in bl if not (b['t'] == 'img' and b['src'] == hero)]
    for b in bl:
        if b['t'] == 'img': b['src'] = img(b['src'], f'blog/{slug}-{len(IMG)}')
    title = d['h1'][0] if d['h1'] and d['h1'][0] else re.sub(r'\s*[-|–].*Рефлекс.*$', '', d['title'])
    fp = first_p(bl); exc = re.sub(r'\*\*', '', fp['x']) if fp else ''
    posts.append({'slug': slug, 'title': title, 'date': m['date'][:10], 'cat': cats.get((m.get('categories') or [0])[0], 'Блог'),
                  'img': img(hero, f'blog/{slug}') if hero else None, 'desc': d['desc'] or mk_desc(exc), 'excerpt': mk_desc(exc), 'blocks': bl})
    redirects[path] = f'/blog/{slug}'
posts.sort(key=lambda p: p['date'], reverse=True)

legal = {k: clean(P[BASE + u]['blocks']) for k, u in [('privacy', '/privacy-policy-2/'), ('terms', '/terms-conditions/')]}
redirects.update({'/privacy-policy-2/': '/politika-za-poveritelnost', '/terms-conditions/': '/obshti-uslovia', '/za-nas/': '/za-nas',
  '/za-nas/nashite-klienti/': '/za-nas', '/za-nas/mediite-za-nas/': '/za-nas', '/galeriq/': '/galeriya', '/kontakti/': '/kontakti',
  '/ceni-za-pochistvane/': '/ceni', '/blog/': '/blog', '/uslugi-za-pochistvane/': '/uslugi', '/links/': '/',
  '/uslugi-za-pochistvane/chastni-klienti/dezinfekcia-jilishtni-vhodove-sgradi-ofisi-meka-mebel-nastilki-coronavirus-covid-19/': '/uslugi'})
for c in ['za-pochistvane', 'za-pochistvashtata-firma', 'prane', 'profesionalno-pochistvane', 'stakla', 'saveti-za-pochistvane', 'uncategorized']:
    redirects[f'/category/{c}/'] = '/blog'
json.dump({'services': services, 'posts': posts, 'legal': legal, 'redirects': redirects, 'images': IMG}, open('site/content.json', 'w'), ensure_ascii=False)
print(len(services), 'services', len(posts), 'posts', len(IMG), 'images', len(redirects), 'redirects')
