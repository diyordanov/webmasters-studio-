set -e
export APP=/home/user/website-498d23dc9e7090023676598a/app
W=/home/user/work; mkdir -p $W/site; cd $W
cp /home/user/rx3/pipe/*.py .
pip install --quiet --break-system-packages lxml >/dev/null 2>&1 || true
curl -s "https://reflex-m.com/wp-json/wp/v2/pages?per_page=100&_fields=id,link,title" -o pages.json
curl -s "https://reflex-m.com/wp-json/wp/v2/posts?per_page=100&_fields=id,link,title,date,categories" -o posts.json
curl -s "https://reflex-m.com/wp-json/wp/v2/categories?per_page=100&_fields=id,name" -o cats.json
python3 extract.py pages.json site/pages.json
python3 extract.py posts.json site/posts.json
python3 misc.py
python3 build_content.py
echo "== media"; python3 media.py
python3 write_content.py
echo "== code"
cd $APP && cp -r /home/user/rx3/src/. src/ && cp /home/user/rx3/pages.css . && python3 $W/patch.py
echo PIPE-DONE
