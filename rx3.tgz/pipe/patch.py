import os
APP = os.environ['APP']
def edit(p, pairs):
    p = f'{APP}/{p}'; s = open(p).read()
    for a, b in pairs:
        if a not in s: raise SystemExit(f'patch miss in {p}: {a[:60]}')
        s = s.replace(a, b)
    open(p, 'w').write(s)

edit('src/components/site/chrome.tsx', [
    ('{ href: "/#uslugi", label: "Услуги" }', '{ href: "/uslugi", label: "Услуги" }'),
    ('{ href: "/#ceni", label: "Цени" }', '{ href: "/ceni", label: "Цени" }'),
    ('{ href: "/#kontakti", label: "Контакти" }', '{ href: "/kontakti", label: "Контакти" }'),
    ('        <span>Фирма за почистване в София</span>', '''        <span className="rx-footer__links">
          <a href="/obshti-uslovia">Общи условия</a>
          <a href="/politika-za-poveritelnost">Политика за поверителност</a>
        </span>'''),
])
edit('src/components/site/areas.tsx', [('function MapEmbed()', 'export function MapEmbed()')])
edit('src/server.ts', [
    ('import { applySecurityHeaders } from "./lib/security-headers.server";', '''import { applySecurityHeaders } from "./lib/security-headers.server";
import redirectMap from "./content/redirects.json";

const REDIRECTS = redirectMap as Record<string, string>;

/** Old WordPress addresses keep their ranking: each answers with a 301 to its new page. */
function redirectFor(url: URL): string | null {
  let path: string;
  try {
    path = decodeURI(url.pathname);
  } catch {
    path = url.pathname;
  }
  const slashed = path.endsWith("/") ? path : `${path}/`;
  const target = REDIRECTS[path] ?? REDIRECTS[slashed];
  if (target && target !== path) return target;
  if (path !== "/" && path.endsWith("/") && !path.startsWith("/assets/")) return url.pathname.slice(0, -1);
  return null;
}'''),
    ('''  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {''', '''  async fetch(request: Request, env: unknown, ctx: unknown) {
    const url = new URL(request.url);
    const to = redirectFor(url);
    if (to) {
      return applySecurityHeaders(
        new Response(null, { status: 301, headers: { Location: `${to}${url.search}`, "Cache-Control": "public, max-age=86400" } }),
      );
    }
    try {'''),
])
css = f'{APP}/src/components/site/site.css'
s = open(css).read()
if 'inner pages' not in s:
    s += open(f'{APP}/pages.css').read() + '\n.rx-footer__links { display: flex; flex-wrap: wrap; gap: 18px; }\n'
    open(css, 'w').write(s)
os.remove(f'{APP}/pages.css')
print('patched')
