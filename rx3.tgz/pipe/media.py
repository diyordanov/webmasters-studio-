import json, os, re, urllib.request, io, concurrent.futures as cf
from PIL import Image, ImageOps
R = os.environ['APP'] + '/public/assets'
c = json.load(open('site/content.json')); m = json.load(open('site/misc.json'))

def dl(u):
    try: return urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'}), timeout=60).read()
    except Exception: return None

def save(img, path, w, q=78):
    im = img.copy()
    if im.width > w: im = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
    os.makedirs(os.path.dirname(path), exist_ok=True); im.save(path, 'WEBP', quality=q, method=6); return im.size

def photo(job):
    src, base, big, small = job
    stem, ext = src.rsplit('.', 1)
    for u in [src, f'{stem}-scaled.{ext}', f'{stem}-1024x576.{ext}']:
        b = dl(u)
        if not b: continue
        try:
            im = ImageOps.exif_transpose(Image.open(io.BytesIO(b))).convert('RGB')
        except Exception:
            continue
        s1 = save(im, f'{R}/{base}.webp', big); s2 = save(im, f'{R}/{base}-s.webp', small)
        return base, {'w': s2[0], 'h': s2[1], 'W': s1[0], 'H': s1[1]}
    return base, None

jobs = [(src, base, 1400, 700) for src, base in c['images'].items()]
gal = list(dict.fromkeys(re.sub(r'-\d+x\d+(\.\w+)$', r'\1', g) for g in m['https://reflex-m.com/galeriq/']['imgs']))
jobs += [(g, f'gal/g-{i+1:03d}', 1600, 640) for i, g in enumerate(gal)]
zn = m['https://reflex-m.com/za-nas/']['imgs']
jobs += [(g, f'za-nas/z-{i+1}', 1400, 700) for i, g in enumerate(zn)]
out = {}
with cf.ThreadPoolExecutor(8) as ex:
    for base, d in ex.map(photo, jobs): out[base] = d

def logo(u):
    b = dl(u)
    if not b: return None
    im = Image.open(io.BytesIO(b)).convert('RGBA')
    bg = Image.new('RGBA', im.size, (255, 255, 255, 255)); bg.alpha_composite(im); im = bg.convert('RGB')
    im.thumbnail((360, 120), Image.LANCZOS)
    name = re.sub(r'[^a-z0-9]+', '-', os.path.splitext(u.rsplit('/', 1)[1].lower())[0]).strip('-')
    p = f'{R}/clients/all/{name}.webp'; os.makedirs(os.path.dirname(p), exist_ok=True); im.save(p, 'WEBP', quality=85)
    return {'src': f'/assets/clients/all/{name}.webp', 'w': im.width, 'h': im.height}
with cf.ThreadPoolExecutor(8) as ex:
    logos = [l for l in ex.map(logo, m['https://reflex-m.com/za-nas/nashite-klienti/']['imgs']) if l]

yts = ['ufLEPiyc10g', 'SGYDORFsDlk', '65oI7sV7-Q0', 'tcitudd1clM', 'ZCGdEOZQnbs'] + m['https://reflex-m.com/za-nas/mediite-za-nas/']['yt']
os.makedirs(f'{R}/video', exist_ok=True)
def yt(i):
    if os.path.exists(f'{R}/video/{i}.webp'): return i
    for q in ['maxresdefault', 'sddefault', 'hqdefault']:
        b = dl(f'https://i.ytimg.com/vi/{i}/{q}.jpg')
        if b and len(b) > 5000:
            im = Image.open(io.BytesIO(b)).convert('RGB')
            bb = im.convert('L').point(lambda v: 255 if v > 18 else 0).getbbox()
            if bb: im = im.crop(bb)
            ImageOps.fit(im, (960, 540), Image.LANCZOS).save(f'{R}/video/{i}.webp', 'WEBP', quality=78); return i
    return None
with cf.ThreadPoolExecutor(6) as ex: ytok = [x for x in ex.map(yt, yts) if x]
json.dump({'img': out, 'gallery': [f'gal/g-{i+1:03d}' for i in range(len(gal))], 'logos': logos, 'yt': ytok,
           'zanas': [f'za-nas/z-{i+1}' for i in range(len(zn))]}, open('site/media.json', 'w'))
print('photos', sum(1 for v in out.values() if v), 'missing', [k for k, v in out.items() if not v], 'logos', len(logos), 'yt', len(ytok))
