import json, os, re, urllib.request
A = os.environ['APP'] + '/src/content'
c = json.load(open('site/content.json')); m = json.load(open('site/media.json')); mi = json.load(open('site/misc.json'))
D = m['img']
def im(base, alt=None):
    if not base or not D.get(base): return None
    d = D[base]; o = {'src': '/assets/' + base, 'w': d['w'], 'h': d['h'], 'W': d['W'], 'H': d['H']}
    if alt: o['alt'] = alt
    return o
def fix(blocks):
    out = []
    for b in blocks:
        if b['t'] == 'img':
            x = im(b['src'], b.get('alt'))
            if x: x['t'] = 'img'; out.append(x)
        else: out.append(b)
    return out
def excerpt(t, n=150):
    t = re.sub(r'\*\*', '', t or '')
    return t if len(t) <= n else t[:n].rsplit(' ', 1)[0] + '…'
for sub in ('services', 'posts'):
    os.makedirs(f'{A}/{sub}', exist_ok=True)
    for f in os.listdir(f'{A}/{sub}'): os.remove(f'{A}/{sub}/{f}')
si = []
for s in c['services']:
    card = {'slug': s['slug'], 'name': s['name'], 'group': s['group'], 'img': im(s['img']), 'excerpt': excerpt(s['intro'])}
    si.append(card)
    json.dump({**card, 'desc': s['desc'], 'intro': s['intro'], 'blocks': fix(s['blocks'])}, open(f"{A}/services/{s['slug']}.json", 'w'), ensure_ascii=False)
json.dump(si, open(A + '/services-index.json', 'w'), ensure_ascii=False)
pi = []
for p in c['posts']:
    card = {'slug': p['slug'], 'title': p['title'], 'date': p['date'], 'cat': p['cat'], 'img': im(p['img']), 'excerpt': p['excerpt']}
    pi.append(card)
    json.dump({**card, 'desc': p['desc'], 'blocks': fix(p['blocks'])}, open(f"{A}/posts/{p['slug']}.json", 'w'), ensure_ascii=False)
json.dump(pi, open(A + '/posts-index.json', 'w'), ensure_ascii=False)
json.dump({k: fix(v) for k, v in c['legal'].items()}, open(A + '/legal.json', 'w'), ensure_ascii=False)
json.dump([im(g) for g in m['gallery'] if im(g)], open(A + '/gallery.json', 'w'))
json.dump(c['redirects'], open(A + '/redirects.json', 'w'), ensure_ascii=False, indent=0)
def ytt(i):
    try: return json.loads(urllib.request.urlopen(f'https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v={i}&format=json', timeout=20).read())['title']
    except Exception: return None
TEST = [('ufLEPiyc10g', 'Христо Христов, директор „Дом на киното“'), ('SGYDORFsDlk', 'Теодора Илиева, сп. „Фасилитис“'),
        ('65oI7sV7-Q0', 'Иван Хинов, управител „Вали Компютърс“'), ('tcitudd1clM', 'Катрин Петкова, търговски директор „Содексо Пасс България“'),
        ('ZCGdEOZQnbs', 'Евелина Георгиева, „Експрес Дайгностикс Глобал“')]
media = []
for i in mi['https://reflex-m.com/za-nas/mediite-za-nas/']['yt']:
    if i in m['yt']:
        t = ytt(i)
        if t: media.append({'id': i, 'title': t})
logos = []
for l in m['logos']:
    n = os.path.basename(l['src']).rsplit('.', 1)[0]
    logos.append({**l, 'name': 'Клиент на Рефлекс М' if n.startswith('screenshot') else n.replace('-', ' ').title()})
about = {'images': [x for x in (im(z) for z in m['zanas']) if x], 'logos': logos,
         'testimonials': [{'id': i, 'title': t, 'label': 'Клиент'} for i, t in TEST if i in m['yt']], 'media': media}
json.dump(about, open(A + '/about.json', 'w'), ensure_ascii=False)
print(len(si), len(pi), len(about['images']), len(logos), len(about['testimonials']), len(media))
