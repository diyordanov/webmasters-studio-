import json, re, html, urllib.request, concurrent.futures as cf, sys
from lxml import html as LH

UA = {'User-Agent': 'Mozilla/5.0'}
def get(u):
    try:
        return urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=40).read().decode('utf8', 'ignore')
    except Exception:
        return None

def norm(t): return re.sub(r'\s+', ' ', t).strip()

def inline(el):
    out = ''
    if el.text: out += el.text
    for c in el:
        tag = c.tag if isinstance(c.tag, str) else ''
        inner = inline(c)
        if tag in ('strong', 'b'): out += ('**' + norm(inner) + '**') if norm(inner) else inner
        elif tag == 'br': out += ' '
        elif tag == 'img': pass
        else: out += inner
        if c.tail: out += c.tail
    return out

def blocks(root):
    res = []
    def walk(el):
        for c in el:
            tag = c.tag if isinstance(c.tag, str) else ''
            if tag == 'h1': continue
            if tag in ('h2', 'h3', 'h4', 'h5', 'h6'):
                t = norm(inline(c)).replace('**', '')
                if t: res.append({'t': 'h', 'l': 2 if tag == 'h2' else 3, 'x': t})
            elif tag in ('p', 'div', 'blockquote') and not c.xpath('.//p|.//ul|.//ol|.//h2|.//h3|.//h4|.//table'):
                for im in c.xpath('.//img'):
                    s = im.get('data-src') or im.get('src')
                    if s and 'wp-content/uploads' in s: res.append({'t': 'img', 'src': s, 'alt': im.get('alt', '')})
                t = norm(inline(c))
                if t and t not in ('**',): res.append({'t': 'p', 'x': t})
            elif tag in ('ul', 'ol'):
                items = [norm(inline(li)) for li in c.xpath('./li')]
                items = [i for i in items if i]
                if items: res.append({'t': 'ul' if tag == 'ul' else 'ol', 'i': items})
            elif tag == 'table':
                rows = [[norm(inline(td)) for td in tr.xpath('./th|./td')] for tr in c.xpath('.//tr')]
                if rows: res.append({'t': 'table', 'r': rows})
            elif tag == 'img':
                s = c.get('data-src') or c.get('src')
                if s and 'wp-content/uploads' in s: res.append({'t': 'img', 'src': s, 'alt': c.get('alt', '')})
            elif tag in ('script', 'style', 'form', 'noscript', 'iframe'):
                if tag == 'iframe' and 'youtube' in (c.get('src') or ''): res.append({'t': 'yt', 'src': c.get('src')})
            else:
                walk(c)
    walk(root)
    return res

def page(u):
    h = get(u)
    if not h: return u, None
    d = LH.fromstring(h)
    title = d.xpath('string(//title)')
    desc = (d.xpath('//meta[@name="description"]/@content') or [''])[0]
    h1 = [norm(x.text_content()) for x in d.xpath('//h1')]
    post = d.xpath('//section[contains(@class,"single_post")]//div[@class="content"]')
    if post:
        h1 = [norm(x.text_content()) for x in d.xpath('//div[contains(@class,"page_title")]//h2')]
    post = post or d.xpath('//div[@class="content"]//div[starts-with(@id,"post-")]') or d.xpath('//div[starts-with(@id,"post-")]')
    if not post:
        hs = d.xpath('//div[@class="content"]/h1') or d.xpath('//h1')
        if hs: post = [hs[0].getparent()]
    bl = blocks(post[0]) if post else []
    return u, {'title': norm(title), 'desc': desc, 'h1': h1, 'blocks': bl}

src, dst = sys.argv[1], sys.argv[2]
urls = [p['link'] for p in json.load(open(src))]
out = {}
with cf.ThreadPoolExecutor(8) as ex:
    for u, v in ex.map(page, urls):
        if v: out[u] = v
json.dump(out, open(dst, 'w'), ensure_ascii=False)
print(dst, len(out))
