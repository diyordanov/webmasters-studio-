import { Fragment, useState, type ReactNode } from "react";

export type Img = { src: string; w: number; h: number; W: number; H: number; alt?: string };

export type Block =
  | { t: "h"; l: 2 | 3; x: string }
  | { t: "p"; x: string }
  | { t: "ul" | "ol"; i: string[] }
  | { t: "table"; r: string[][] }
  | ({ t: "img" } & Img)
  | { t: "faq"; i: { q: string; a: string }[] }
  | { t: "yt"; src: string };

/** Renders the **bold** markers kept from the original texts. */
export function Rich({ x }: { x: string }) {
  const parts = x.split(/\*\*(.+?)\*\*/g);
  return (
    <>
      {parts.map((p, i) => (i % 2 ? <strong key={i}>{p}</strong> : <Fragment key={i}>{p}</Fragment>))}
    </>
  );
}

export function plain(x: string) {
  return x.replace(/\*\*/g, "");
}

export function Picture({
  img,
  alt,
  sizes = "(max-width: 860px) 92vw, 720px",
  eager,
  className,
}: {
  img: Img;
  alt: string;
  sizes?: string;
  eager?: boolean;
  className?: string;
}) {
  return (
    <img
      className={className}
      src={`${img.src}-s.webp`}
      srcSet={`${img.src}-s.webp ${img.w}w, ${img.src}.webp ${img.W}w`}
      sizes={sizes}
      alt={alt}
      width={img.w}
      height={img.h}
      loading={eager ? "eager" : "lazy"}
      fetchPriority={eager ? "high" : undefined}
      decoding="async"
    />
  );
}

function YouTube({ src }: { src: string }) {
  const id = /embed\/([\w-]+)/.exec(src)?.[1];
  const [on, setOn] = useState(false);
  if (!id) return null;
  return (
    <div className="rx-video__frame rx-prose__video">
      {on ? (
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`}
          title="Видео от Рефлекс М"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"
          allowFullScreen
        />
      ) : (
        <button type="button" className="rx-video__play" onClick={() => setOn(true)} aria-label="Пусни видеото">
          <img src={`https://i.ytimg.com/vi/${id}/hqdefault.jpg`} alt="" loading="lazy" width={480} height={360} />
          <span className="rx-video__icon" aria-hidden="true" />
        </button>
      )}
    </div>
  );
}

/** Long-form content (service texts, articles, legal pages) from the content files. */
export function Prose({ blocks, title }: { blocks: Block[]; title: string }) {
  const out: ReactNode[] = [];
  blocks.forEach((b, i) => {
    switch (b.t) {
      case "h":
        out.push(b.l === 2 ? <h2 key={i}>{b.x}</h2> : <h3 key={i}>{b.x}</h3>);
        break;
      case "p":
        out.push(
          <p key={i}>
            <Rich x={b.x} />
          </p>,
        );
        break;
      case "ul":
      case "ol": {
        const L = b.t;
        out.push(
          <L key={i} className={L === "ul" ? "rx-ticks" : undefined}>
            {b.i.map((x, j) => (
              <li key={j}>
                <Rich x={x} />
              </li>
            ))}
          </L>,
        );
        break;
      }
      case "table":
        out.push(
          <div key={i} className="rx-table">
            <table>
              <tbody>
                {b.r.map((row, j) => (
                  <tr key={j}>
                    {row.map((c, k) => (
                      <td key={k}>
                        <Rich x={c} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>,
        );
        break;
      case "img":
        out.push(
          <figure key={i} className="rx-prose__fig">
            <Picture img={b} alt={b.alt || title} />
          </figure>,
        );
        break;
      case "faq":
        out.push(
          <div key={i} className="rx-prose__faq">
            {b.i.map((f) => (
              <details key={f.q} className="rx-qa">
                <summary>
                  <span className="rx-qa__q">{f.q}</span>
                  <span className="rx-qa__icon" aria-hidden="true" />
                </summary>
                <p>{f.a}</p>
              </details>
            ))}
          </div>,
        );
        break;
      case "yt":
        out.push(<YouTube key={i} src={b.src} />);
        break;
    }
  });
  return <div className="rx-prose">{out}</div>;
}

export function faqOf(blocks: Block[]) {
  return blocks.flatMap((b) => (b.t === "faq" ? b.i : []));
}
