import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "./page";
import { Prose, type Block } from "./prose";
import legal from "../../content/legal.json";

const L = legal as { privacy: Block[]; terms: Block[] };

export const LEGAL = {
  privacy: { title: "Политика за поверителност", path: "/politika-za-poveritelnost", blocks: L.privacy },
  terms: { title: "Общи условия", path: "/obshti-uslovia", blocks: L.terms },
} as const;

export function legalHead(key: keyof typeof LEGAL) {
  const p = LEGAL[key];
  const head = pageHead({
    title: `${p.title} | Рефлекс М`,
    description: `${p.title} на сайта на Рефлекс М ООД — фирма за почистване в София.`,
    path: p.path,
    schema: [crumbsLd([{ name: "Начало", href: "/" }, { name: p.title, href: p.path }])],
  });
  head.meta = head.meta.map((m) => ("name" in m && m.name === "robots" ? { name: "robots", content: "index, nofollow" } : m));
  return head;
}

export function LegalPage({ k }: { k: keyof typeof LEGAL }) {
  const p = LEGAL[k];
  return (
    <PageShell>
      <PageHead crumbs={[{ name: "Начало", href: "/" }, { name: p.title, href: p.path }]} title={p.title} />
      <section className="rx-wrap rx-prose-wrap rx-legal">
        <Prose blocks={p.blocks} title={p.title} />
      </section>
      <CtaBand />
    </PageShell>
  );
}
