import { useState } from "react";

export type Video = { id: string; title: string; label?: string };

/** Grid of YouTube videos: a local poster first, the privacy-enhanced player only after a click. */
export function VideoGrid({ videos }: { videos: Video[] }) {
  const [playing, setPlaying] = useState<string | null>(null);
  return (
    <ul className="rx-videos__grid">
      {videos.map((v) => (
        <li key={v.id} className="rx-video">
          <div className="rx-video__frame">
            {playing === v.id ? (
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${v.id}?autoplay=1&rel=0&modestbranding=1`}
                title={v.title}
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                allowFullScreen
              />
            ) : (
              <button type="button" className="rx-video__play" onClick={() => setPlaying(v.id)} aria-label={`Пусни видеото: ${v.title}`}>
                <img src={`/assets/video/${v.id}.webp`} alt="" width={960} height={540} loading="lazy" decoding="async" />
                <span className="rx-video__icon" aria-hidden="true" />
              </button>
            )}
          </div>
          <p className="rx-video__cap">
            {v.label ? <span>{v.label}</span> : null} {v.title}
          </p>
        </li>
      ))}
    </ul>
  );
}
