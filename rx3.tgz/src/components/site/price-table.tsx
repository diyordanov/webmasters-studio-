import type { PriceGroup } from "./prices";

export function PriceTable({ group, compact }: { group: PriceGroup; compact?: boolean }) {
  return (
    <div className={`rx-ptable${compact ? " rx-ptable--compact" : ""}`}>
      <div className="rx-ptable__head">
        <h2 className={compact ? "rx-h3" : "rx-ptable__t"}>{compact ? `Цени: ${group.title.toLowerCase()}` : group.title}</h2>
        {group.note ? <p>{group.note}</p> : null}
      </div>
      <table>
        <thead className="rx-sr">
          <tr>
            <th scope="col">Услуга</th>
            <th scope="col">Цена в евро</th>
            <th scope="col">Цена в лева</th>
          </tr>
        </thead>
        <tbody>
          {group.rows.map((r) => (
            <tr key={r.name}>
              <th scope="row">{r.name}</th>
              <td className="rx-ptable__eur">
                {r.eur} €<span>/{r.unit}</span>
              </td>
              <td className="rx-ptable__bgn">{r.bgn} лв.</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
