import type { ReactNode } from "react";

import { PhoneIcon, SiteFooter, SiteHeader } from "./chrome";
import { BRAND, OG_IMAGE, PHONE_MOBILE, RATING, SITE_URL } from "./data";

export type Crumb = { name: string; href: string };

/** Head tags for an inner page: unique title/description, canonical, social tags and JSON-LD. */
export function pageHead({
  title,
  description,
  path,
  image,
  schema,
  type = "website",
}: {
  title: string;
  description: string;
  path: string;
  image?: string;
  schema?: object[];
  type?: "website" | "article";
}) {
  const url = `${SITE_URL}${path}`;
  const img = image ? `${SITE_URL}${image}` : OG_IMAGE;
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { name: "robots", content: "index, follow, max-image-preview:large" },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: type },
      { property: "og:url", content: url },
      { property: "og:locale", content: "bg_BG" },
      { property: "og:site_name", content: BRAND },
      { property: "og:image", content: img },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: img },
    ],
    links: [{ rel: "canonical", href: url }],
    scripts: schema?.length
      ? [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@graph": schema }) }]
      : [],
  };
}

export function crumbsLd(crumbs: Crumb[]) {
  return {
    "@type": "BreadcrumbList",
    itemListElement: crumbs.map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.name, item: `${SITE_URL}${c.href}` })),
  };
}

/** Title tag: "<page> | Рефлекс М", trimmed to stay readable in search results. */
export function titleOf(name: string) {
  const t = `${name} | ${BRAND}`;
  return t.length <= 62 ? t : name;
}

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="rx rx-inner">
      <a className="rx-skip" href="#sadarzhanie">
        Към съдържанието
      </a>
      <SiteHeader />
      <main id="sadarzhanie">{children}</main>
      <SiteFooter />
    </div>
  );
}

export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav className="rx-crumbs" aria-label="Навигационна пътека">
      <ol>
        {items.map((c, i) => (
          <li key={c.href}>
            {i < items.length - 1 ? <a href={c.href}>{c.name}</a> : <span aria-current="page">{c.name}</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}

/** Plain page header: breadcrumbs, eyebrow, H1 and lead. */
export function PageHead({
  crumbs,
  eyebrow,
  title,
  lead,
  children,
}: {
  crumbs: Crumb[];
  eyebrow?: string;
  title: string;
  lead?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <header className="rx-phead">
      <div className="rx-wrap">
        <Breadcrumbs items={crumbs} />
        {eyebrow ? <p className="rx-eyebrow">{eyebrow}</p> : null}
        <h1 className="rx-h1">{title}</h1>
        {lead ? <div className="rx-lead rx-phead__lead">{lead}</div> : null}
        {children}
      </div>
    </header>
  );
}

/** Sticky side card: phone, free inspection, rating. */
export function CtaCard({ children }: { children?: ReactNode }) {
  return (
    <aside className="rx-ctacard" aria-label="Заявете оглед">
      <p className="rx-ctacard__k">Безплатен оглед</p>
      <p className="rx-ctacard__t">Получете оферта с крайна цена</p>
      <a className="rx-btn rx-btn--primary" href={PHONE_MOBILE.href}>
        <PhoneIcon /> {PHONE_MOBILE.label}
      </a>
      <a className="rx-btn rx-btn--ghost" href="/kontakti">
        Изпратете запитване
      </a>
      <p className="rx-ctacard__r">
        <span className="rx-stars" aria-hidden="true">
          ★★★★★
        </span>{" "}
        {RATING.value} от {RATING.count} отзива в Google
      </p>
      {children}
    </aside>
  );
}

/** Dark closing band used at the bottom of inner pages. */
export function CtaBand({ title = "Заявете безплатен оглед" }: { title?: string }) {
  return (
    <section className="rx-band" aria-label="Контакт">
      <div className="rx-wrap rx-band__in">
        <div>
          <p className="rx-eyebrow">{BRAND}</p>
          <p className="rx-band__t">{title}</p>
          <p className="rx-band__s">Идваме на място, преценяваме обекта и ви даваме оферта с крайна цена.</p>
        </div>
        <div className="rx-band__a">
          <a className="rx-btn rx-btn--primary" href={PHONE_MOBILE.href}>
            <PhoneIcon /> {PHONE_MOBILE.label}
          </a>
          <a className="rx-btn rx-btn--ghost" href="/kontakti">
            Пишете ни
          </a>
        </div>
      </div>
    </section>
  );
}
