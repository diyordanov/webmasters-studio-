/** Price list from the company's current price page (EUR, VAT excluded). */
export type PriceRow = { name: string; eur: string; bgn: string; unit: string };
export type PriceGroup = { id: string; title: string; note?: string; rows: PriceRow[] };

export const PRICES: PriceGroup[] = [
  {
    id: "meki",
    title: "Пране на мека мебел и меки настилки",
    rows: [
      { name: "Ъглов диван", eur: "64,00", bgn: "125,00", unit: "бр." },
      { name: "Диван тройка", eur: "51,00", bgn: "100,00", unit: "бр." },
      { name: "Диван двойка", eur: "41,00", bgn: "80,00", unit: "бр." },
      { name: "Фотьойл", eur: "30,70", bgn: "60,00", unit: "бр." },
      { name: "Табуретка, стол", eur: "6,10", bgn: "12,00", unit: "бр." },
      { name: "Матрак, двустранно, до 160×200 см", eur: "51,00", bgn: "100,00", unit: "бр." },
      { name: "Пране на килим, мокет", eur: "1,80", bgn: "3,50", unit: "кв.м" },
      { name: "Прахосмукиране на подови настилки", eur: "0,56", bgn: "1,10", unit: "кв.м" },
    ],
  },
  {
    id: "tvardi",
    title: "Почистване на твърди настилки",
    note: "Мрамор, мозайка, теракот, гранитогрес, ламинат и др.",
    rows: [
      { name: "Машинно измиване", eur: "0,56", bgn: "1,10", unit: "кв.м" },
      { name: "Ръчно измиване", eur: "0,92", bgn: "1,80", unit: "кв.м" },
      { name: "Полиране (запечатка), два слоя", eur: "2,10", bgn: "4,20", unit: "кв.м" },
    ],
  },
  {
    id: "stakla",
    title: "Стъкла, дограми и щори",
    note: "Цените за стъкла са за едностранно почистване.",
    rows: [
      { name: "Стъкла с височина до 3 м", eur: "1,28", bgn: "2,50", unit: "кв.м" },
      { name: "Стъкла с височина над 3 м", eur: "2,14", bgn: "4,20", unit: "кв.м" },
      { name: "Почистване на дограма и профили", eur: "1,28", bgn: "2,50", unit: "л.м" },
      { name: "Алпинисти, вишка, скеле", eur: "2,30", bgn: "4,50", unit: "кв.м" },
      { name: "Обезпрашаване на ламелни щори", eur: "1,17", bgn: "2,30", unit: "кв.м" },
    ],
  },
  {
    id: "sanitaren",
    title: "Санитарен фаянс",
    rows: [
      { name: "Тоалетна чиния", eur: "12,80", bgn: "25,00", unit: "бр." },
      { name: "Вана, джакузи, душ кабина", eur: "25,55", bgn: "50,00", unit: "бр." },
      { name: "Комплексно почистване на баня", eur: "75,15", bgn: "150,00", unit: "бр." },
    ],
  },
  {
    id: "rainbow",
    title: "Почистване с Rainbow",
    rows: [{ name: "Комплексно почистване", eur: "4,30", bgn: "8,50", unit: "кв.м" }],
  },
];

export const PRICE_NOTES = [
  "Всички цени са без включен ДДС.",
  "Минимална стойност на поръчка: 61 € (120 лв.). Не важи за пране на мека мебел.",
  "Цените може да се променят според степента на замърсяване и достъпа до обекта.",
];

export const INDIVIDUAL = [
  "Абонаментно почистване в София",
  "Почистване на банки, администрации, хотели",
  "Производствени и промишлени помещения",
  "Комплексно почистване на офиси и жилища",
  "Почистване на общи площи",
];

/** Which price table belongs on which service page. */
export const PRICE_FOR: Record<string, string> = {
  "prane-na-divani-sofia": "meki",
  "prane-na-meka-mebel": "meki",
  "prane-na-matraci": "meki",
  "prane-na-kilimi": "meki",
  "prane-na-moket": "meki",
  "pochistvane-s-rainbow": "rainbow",
  "pochistvane-na-prozorci-sofia": "stakla",
  "pochistvane-na-stakla": "stakla",
  "pochistvane-na-dograma": "stakla",
  "pochistvane-na-shtori": "stakla",
  "pochistvane-na-banya": "sanitaren",
  "pochistvane-na-vana": "sanitaren",
  "pochistvane-na-dush-kabina": "sanitaren",
  "pochistvane-na-toaletna": "sanitaren",
  "pochistvane-na-toaletna-chinia": "sanitaren",
  "pochistvane-na-mramor": "tvardi",
  "pochistvane-na-granitogres": "tvardi",
  "pochistvane-na-mozaika": "tvardi",
  "pochistvane-na-terakot": "tvardi",
  "pochistvane-na-laminat": "tvardi",
};
