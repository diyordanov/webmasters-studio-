import { createFileRoute } from "@tanstack/react-router";

import postsIndex from "../content/posts-index.json";
import servicesIndex from "../content/services-index.json";

const STATIC = [
  { path: "/", priority: "1.0", freq: "weekly" },
  { path: "/uslugi", priority: "0.9", freq: "monthly" },
  { path: "/ceni", priority: "0.8", freq: "monthly" },
  { path: "/za-nas", priority: "0.6", freq: "yearly" },
  { path: "/galeriya", priority: "0.5", freq: "monthly" },
  { path: "/blog", priority: "0.6", freq: "weekly" },
  { path: "/kontakti", priority: "0.7", freq: "yearly" },
  { path: "/obshti-uslovia", priority: "0.2", freq: "yearly" },
  { path: "/politika-za-poveritelnost", priority: "0.2", freq: "yearly" },
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const origin = new URL(request.url).origin;
        const today = new Date().toISOString().split("T")[0];
        const urls = [
          ...STATIC.map((s) => ({ loc: s.path, lastmod: today, freq: s.freq, priority: s.priority })),
          ...(servicesIndex as { slug: string; group: string }[]).map((s) => ({
            loc: `/uslugi/${s.slug}`,
            lastmod: today,
            freq: "monthly",
            priority: s.group === "main" ? "0.9" : "0.7",
          })),
          ...(postsIndex as { slug: string; date: string }[]).map((p) => ({ loc: `/blog/${p.slug}`, lastmod: p.date, freq: "yearly", priority: "0.5" })),
        ];
        const xml = [
          '<?xml version="1.0" encoding="UTF-8"?>',
          '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
          ...urls.map(
            (u) =>
              `  <url><loc>${origin}${u.loc === "/" ? "/" : u.loc}</loc><lastmod>${u.lastmod}</lastmod><changefreq>${u.freq}</changefreq><priority>${u.priority}</priority></url>`,
          ),
          "</urlset>",
        ].join("\n");
        return new Response(xml, {
          headers: { "Content-Type": "application/xml; charset=utf-8", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});
