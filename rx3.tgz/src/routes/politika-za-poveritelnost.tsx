import { createFileRoute } from "@tanstack/react-router";

import { legalHead, LegalPage } from "@/components/site/legal";

export const Route = createFileRoute("/politika-za-poveritelnost")({
  head: () => legalHead("privacy"),
  component: () => <LegalPage k="privacy" />,
});
