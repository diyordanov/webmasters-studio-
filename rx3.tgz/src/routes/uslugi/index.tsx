import { createFileRoute } from "@tanstack/react-router";

import { GROUPS, SERVICES_INDEX, serviceHref } from "@/components/site/catalog";
import { BRAND, SITE_URL } from "@/components/site/data";
import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";
import { Picture } from "@/components/site/prose";

const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "Услуги", href: "/uslugi" },
];

export const Route = createFileRoute("/uslugi/")({
  head: () =>
    pageHead({
      title: "Услуги за почистване в София | Рефлекс М",
      description:
        "Всички услуги на Рефлекс М: почистване на офиси, апартаменти, входове и обекти след ремонт, пране на мека мебел, миене на прозорци и почистване на настилки в София.",
      path: "/uslugi",
      schema: [
        crumbsLd(CRUMBS),
        {
          "@type": "ItemList",
          name: "Услуги за почистване в София",
          itemListElement: SERVICES_INDEX.map((s, i) => ({ "@type": "ListItem", position: i + 1, name: s.name, url: `${SITE_URL}${serviceHref(s.slug)}` })),
        },
      ],
    }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <PageShell>
      <PageHead
        crumbs={CRUMBS}
        eyebrow="Услуги"
        title="Услуги за почистване в София"
        lead={`${BRAND} почиства офиси, домове, входове и обекти след ремонт, пере мека мебел и настилки и мие прозорци и стъклени фасади. Изберете услуга, за да видите какво включва и как работим.`}
      >
        <nav className="rx-jump" aria-label="Групи услуги">
          {GROUPS.map((g) => (
            <a key={g.id} href={`#${g.id}`}>
              {g.title}
            </a>
          ))}
        </nav>
      </PageHead>
      {GROUPS.map((g) => {
        const items = SERVICES_INDEX.filter((s) => s.group === g.id);
        if (!items.length) return null;
        return (
          <section key={g.id} id={g.id} className="rx-sgroup" aria-labelledby={`h-${g.id}`}>
            <div className="rx-wrap">
              <div className="rx-sgroup__head">
                <h2 id={`h-${g.id}`} className="rx-h2">
                  {g.title}
                </h2>
                <p>{g.text}</p>
              </div>
              <ul className={`rx-sgrid${g.id === "main" ? " rx-sgrid--main" : ""}`}>
                {items.map((s) => (
                  <li key={s.slug}>
                    <a className="rx-scard" href={serviceHref(s.slug)}>
                      <span className="rx-scard__media">
                        {s.img ? <Picture img={s.img} alt="" sizes="(max-width: 860px) 92vw, 400px" /> : null}
                      </span>
                      <span className="rx-scard__body">
                        <span className="rx-scard__t">{s.name}</span>
                        <span className="rx-scard__x">{s.excerpt}</span>
                        <span className="rx-scard__go" aria-hidden="true">
                          Виж услугата →
                        </span>
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        );
      })}
      <CtaBand />
    </PageShell>
  );
}
