import { createFileRoute, notFound } from "@tanstack/react-router";

import { PhoneIcon } from "@/components/site/chrome";
import { relatedServices, serviceHref, type Service } from "@/components/site/catalog";
import { BRAND, PHONE_MOBILE, SITE_URL } from "@/components/site/data";
import { Breadcrumbs, CtaBand, CtaCard, crumbsLd, pageHead, PageShell, titleOf } from "@/components/site/page";
import { PriceTable } from "@/components/site/price-table";
import { PRICE_FOR, PRICES } from "@/components/site/prices";
import { faqOf, Picture, Prose, Rich, plain } from "@/components/site/prose";

const files = import.meta.glob<{ default: Service }>("../../content/services/*.json");

export const Route = createFileRoute("/uslugi/$slug")({
  loader: async ({ params }) => {
    const load = files[`../../content/services/${params.slug}.json`];
    if (!load) throw notFound();
    return (await load()).default;
  },
  head: ({ loaderData: s }) => {
    if (!s) return {};
    const path = serviceHref(s.slug);
    const crumbs = [
      { name: "Начало", href: "/" },
      { name: "Услуги", href: "/uslugi" },
      { name: s.name, href: path },
    ];
    const faq = faqOf(s.blocks);
    return pageHead({
      title: titleOf(s.name),
      description: s.desc,
      path,
      image: s.img ? `${s.img.src}.webp` : undefined,
      schema: [
        {
          "@type": "Service",
          name: s.name,
          serviceType: s.name,
          description: plain(s.intro || s.desc),
          url: `${SITE_URL}${path}`,
          areaServed: { "@type": "City", name: "София" },
          provider: { "@id": `${SITE_URL}/#business` },
        },
        crumbsLd(crumbs),
        ...(faq.length
          ? [
              {
                "@type": "FAQPage",
                mainEntity: faq.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
              },
            ]
          : []),
      ],
    });
  },
  component: ServicePage,
});

function ServicePage() {
  const s = Route.useLoaderData();
  const price = PRICES.find((p) => p.id === PRICE_FOR[s.slug]);
  const related = relatedServices(s.slug, s.group);
  return (
    <PageShell>
      <header className="rx-shero">
        <div className="rx-wrap rx-shero__grid">
          <div className="rx-shero__text">
            <Breadcrumbs
              items={[
                { name: "Начало", href: "/" },
                { name: "Услуги", href: "/uslugi" },
                { name: s.name, href: serviceHref(s.slug) },
              ]}
            />
            <p className="rx-eyebrow">{BRAND} · София</p>
            <h1 className="rx-h1">{s.name}</h1>
            {s.intro ? (
              <p className="rx-lead">
                <Rich x={s.intro} />
              </p>
            ) : null}
            <div className="rx-shero__cta">
              <a className="rx-btn rx-btn--primary" href={PHONE_MOBILE.href}>
                <PhoneIcon /> {PHONE_MOBILE.label}
              </a>
              <a className="rx-btn rx-btn--line" href="/kontakti">
                Безплатен оглед<span aria-hidden="true" className="rx-btn__arrow">→</span>
              </a>
            </div>
            <ul className="rx-shero__chips">
              <li>Безплатен оглед</li>
              <li>Оферта с крайна цена</li>
              <li>Цяла София</li>
            </ul>
          </div>
          {s.img ? (
            <div className="rx-shero__media">
              <Picture img={s.img} alt={`${s.name} — ${BRAND}`} eager sizes="(max-width: 860px) 92vw, 600px" />
            </div>
          ) : null}
        </div>
      </header>

      <div className="rx-wrap rx-article">
        <article className="rx-article__main">
          <Prose blocks={s.blocks} title={s.name} />
          {price ? (
            <section className="rx-article__prices" aria-label="Цени">
              <PriceTable group={price} compact />
              <p className="rx-note">
                Цените са без ДДС. Вижте <a href="/ceni">всички цени за почистване</a>.
              </p>
            </section>
          ) : null}
        </article>
        <div className="rx-article__side">
          <CtaCard />
        </div>
      </div>

      {related.length ? (
        <section className="rx-section rx-related" aria-labelledby="rx-related-h">
          <div className="rx-wrap">
            <h2 id="rx-related-h" className="rx-h2 rx-related__h">
              Свързани услуги
            </h2>
            <ul className="rx-related__grid">
              {related.map((r) => (
                <li key={r.slug}>
                  <a className="rx-mini" href={serviceHref(r.slug)}>
                    {r.img ? <Picture img={r.img} alt="" sizes="(max-width: 860px) 92vw, 380px" /> : <span className="rx-mini__ph" />}
                    <span className="rx-mini__t">{r.name}</span>
                    <span className="rx-mini__x">{r.excerpt}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </section>
      ) : null}
      <CtaBand title={`${s.name}: заявете безплатен оглед`} />
    </PageShell>
  );
}
