import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";

import { BRAND } from "@/components/site/data";
import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";
import type { Img } from "@/components/site/prose";
import gallery from "../content/gallery.json";

const PHOTOS = gallery as Img[];
const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "Галерия", href: "/galeriya" },
];

export const Route = createFileRoute("/galeriya")({
  head: () =>
    pageHead({
      title: "Галерия: снимки от обекти | Рефлекс М",
      description: `Снимки от реални обекти на ${BRAND} — почистване на офиси, домове, входове, стъклени фасади на височина и пране на мека мебел в София.`,
      path: "/galeriya",
      image: PHOTOS[0] ? `${PHOTOS[0].src}.webp` : undefined,
      schema: [crumbsLd(CRUMBS)],
    }),
  component: GalleryPage,
});

function GalleryPage() {
  const [open, setOpen] = useState<number | null>(null);
  const dlg = useRef<HTMLDialogElement>(null);

  const go = useCallback((d: number) => setOpen((i) => (i === null ? i : (i + d + PHOTOS.length) % PHOTOS.length)), []);

  useEffect(() => {
    const el = dlg.current;
    if (!el) return;
    if (open !== null && !el.open) el.showModal();
    if (open === null && el.open) el.close();
  }, [open]);

  useEffect(() => {
    if (open === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, go]);

  const cur = open === null ? null : PHOTOS[open];

  return (
    <PageShell>
      <PageHead
        crumbs={CRUMBS}
        eyebrow="Галерия"
        title="Галерия от наши обекти"
        lead={`${PHOTOS.length} снимки от работата на екипа на ${BRAND} — офиси, домове, входове, стъклени фасади и пране на мека мебел.`}
      />
      <section className="rx-wrap rx-gallery" aria-label="Снимки">
        <ul>
          {PHOTOS.map((p, i) => (
            <li key={p.src}>
              <button type="button" onClick={() => setOpen(i)} aria-label={`Отвори снимка ${i + 1} от ${PHOTOS.length}`}>
                <img
                  src={`${p.src}-s.webp`}
                  alt={`${BRAND} — снимка от обект ${i + 1}`}
                  width={p.w}
                  height={p.h}
                  loading={i < 6 ? "eager" : "lazy"}
                  decoding="async"
                />
              </button>
            </li>
          ))}
        </ul>
      </section>
      <dialog ref={dlg} className="rx-lightbox" onClose={() => setOpen(null)} aria-label="Преглед на снимка">
        {cur ? (
          <>
            <img src={`${cur.src}.webp`} alt={`${BRAND} — снимка от обект ${(open ?? 0) + 1}`} width={cur.W} height={cur.H} />
            <p className="rx-lightbox__count">
              {(open ?? 0) + 1} / {PHOTOS.length}
            </p>
            <button type="button" className="rx-lightbox__btn rx-lightbox__prev" onClick={() => go(-1)} aria-label="Предишна снимка">
              ←
            </button>
            <button type="button" className="rx-lightbox__btn rx-lightbox__next" onClick={() => go(1)} aria-label="Следваща снимка">
              →
            </button>
            <button type="button" className="rx-lightbox__btn rx-lightbox__close" onClick={() => setOpen(null)} aria-label="Затвори">
              ✕
            </button>
          </>
        ) : null}
      </dialog>
      <CtaBand />
    </PageShell>
  );
}
