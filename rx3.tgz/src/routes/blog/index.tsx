import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";

import { bgDate, POSTS_INDEX, postHref } from "@/components/site/catalog";
import { BRAND } from "@/components/site/data";
import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";
import { Picture } from "@/components/site/prose";

const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "Блог", href: "/blog" },
];
const CATS = Array.from(new Set(POSTS_INDEX.map((p) => p.cat)));
const PAGE = 18;

export const Route = createFileRoute("/blog/")({
  head: () =>
    pageHead({
      title: "Блог за почистване: съвети и професионални практики | Рефлекс М",
      description:
        "Съвети за почистване на дома и офиса, пране на мека мебел, грижа за настилки и стъкла — от екипа на Рефлекс М, професионална фирма за почистване в София.",
      path: "/blog",
      schema: [crumbsLd(CRUMBS), { "@type": "Blog", name: `Блог на ${BRAND}`, inLanguage: "bg" }],
    }),
  component: BlogPage,
});

function BlogPage() {
  const [cat, setCat] = useState<string | null>(null);
  const [shown, setShown] = useState(PAGE);
  const list = useMemo(() => POSTS_INDEX.filter((p) => !cat || p.cat === cat), [cat]);
  return (
    <PageShell>
      <PageHead
        crumbs={CRUMBS}
        eyebrow="Блог"
        title="Блог за почистване"
        lead="Практични съвети за почистване на дома и офиса и какво стои зад професионалното почистване — от екипа на Рефлекс М."
      >
        <div className="rx-chips" role="group" aria-label="Категории">
          <button type="button" aria-pressed={cat === null} onClick={() => (setCat(null), setShown(PAGE))}>
            Всички <span>{POSTS_INDEX.length}</span>
          </button>
          {CATS.map((c) => (
            <button key={c} type="button" aria-pressed={cat === c} onClick={() => (setCat(c), setShown(PAGE))}>
              {c} <span>{POSTS_INDEX.filter((p) => p.cat === c).length}</span>
            </button>
          ))}
        </div>
      </PageHead>
      <section className="rx-wrap rx-posts" aria-label="Статии">
        <ul className="rx-pgrid">
          {list.slice(0, shown).map((p, i) => (
            <li key={p.slug}>
              <a className="rx-pcard" href={postHref(p.slug)}>
                <span className="rx-pcard__media">
                  {p.img ? <Picture img={p.img} alt="" eager={i < 3} sizes="(max-width: 860px) 92vw, 400px" /> : null}
                </span>
                <span className="rx-pcard__meta">
                  {p.cat} · <time dateTime={p.date}>{bgDate(p.date)}</time>
                </span>
                <span className="rx-pcard__t">{p.title}</span>
                <span className="rx-pcard__x">{p.excerpt}</span>
              </a>
            </li>
          ))}
        </ul>
        {shown < list.length ? (
          <div className="rx-more">
            <button type="button" className="rx-btn rx-btn--line" onClick={() => setShown((n) => n + PAGE)}>
              Покажи още статии ({list.length - shown})
            </button>
          </div>
        ) : null}
        {/* Crawlers and no-JS visitors still reach every article. */}
        <noscript>
          <ul>
            {POSTS_INDEX.map((p) => (
              <li key={p.slug}>
                <a href={postHref(p.slug)}>{p.title}</a>
              </li>
            ))}
          </ul>
        </noscript>
      </section>
      <CtaBand />
    </PageShell>
  );
}
