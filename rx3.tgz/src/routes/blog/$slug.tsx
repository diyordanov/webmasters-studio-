import { createFileRoute, notFound } from "@tanstack/react-router";

import { bgDate, POSTS_INDEX, postHref, type Post } from "@/components/site/catalog";
import { BRAND, SITE_URL } from "@/components/site/data";
import { Breadcrumbs, CtaBand, CtaCard, crumbsLd, pageHead, PageShell, titleOf } from "@/components/site/page";
import { faqOf, Picture, Prose } from "@/components/site/prose";

const files = import.meta.glob<{ default: Post }>("../../content/posts/*.json");

export const Route = createFileRoute("/blog/$slug")({
  loader: async ({ params }) => {
    const load = files[`../../content/posts/${params.slug}.json`];
    if (!load) throw notFound();
    return (await load()).default;
  },
  head: ({ loaderData: p }) => {
    if (!p) return {};
    const path = postHref(p.slug);
    const crumbs = [
      { name: "Начало", href: "/" },
      { name: "Блог", href: "/blog" },
      { name: p.title, href: path },
    ];
    const faq = faqOf(p.blocks);
    return pageHead({
      title: titleOf(p.title),
      description: p.desc,
      path,
      type: "article",
      image: p.img ? `${p.img.src}.webp` : undefined,
      schema: [
        {
          "@type": "BlogPosting",
          headline: p.title,
          description: p.desc,
          datePublished: p.date,
          inLanguage: "bg",
          articleSection: p.cat,
          mainEntityOfPage: `${SITE_URL}${path}`,
          ...(p.img ? { image: `${SITE_URL}${p.img.src}.webp` } : {}),
          author: { "@type": "Organization", name: BRAND, url: `${SITE_URL}/` },
          publisher: { "@id": `${SITE_URL}/#business` },
        },
        crumbsLd(crumbs),
        ...(faq.length
          ? [
              {
                "@type": "FAQPage",
                mainEntity: faq.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
              },
            ]
          : []),
      ],
    });
  },
  component: PostPage,
});

function PostPage() {
  const p = Route.useLoaderData();
  const more = POSTS_INDEX.filter((x) => x.cat === p.cat && x.slug !== p.slug).slice(0, 3);
  return (
    <PageShell>
      <header className="rx-phead rx-phead--post">
        <div className="rx-wrap rx-post__head">
          <Breadcrumbs
            items={[
              { name: "Начало", href: "/" },
              { name: "Блог", href: "/blog" },
              { name: p.title, href: postHref(p.slug) },
            ]}
          />
          <p className="rx-eyebrow">
            {p.cat} · <time dateTime={p.date}>{bgDate(p.date)}</time>
          </p>
          <h1 className="rx-h1 rx-post__title">{p.title}</h1>
        </div>
        {p.img ? (
          <div className="rx-wrap">
            <div className="rx-post__media">
              <Picture img={p.img} alt={p.title} eager sizes="(max-width: 1240px) 92vw, 1100px" />
            </div>
          </div>
        ) : null}
      </header>
      <div className="rx-wrap rx-article">
        <article className="rx-article__main">
          <Prose blocks={p.blocks} title={p.title} />
        </article>
        <div className="rx-article__side">
          <CtaCard>
            <a className="rx-ctacard__l" href="/uslugi">
              Всички услуги за почистване →
            </a>
          </CtaCard>
        </div>
      </div>
      {more.length ? (
        <section className="rx-section rx-related" aria-labelledby="rx-more-h">
          <div className="rx-wrap">
            <h2 id="rx-more-h" className="rx-h2 rx-related__h">
              Още статии: {p.cat}
            </h2>
            <ul className="rx-pgrid">
              {more.map((x) => (
                <li key={x.slug}>
                  <a className="rx-pcard" href={postHref(x.slug)}>
                    <span className="rx-pcard__media">{x.img ? <Picture img={x.img} alt="" sizes="(max-width: 860px) 92vw, 400px" /> : null}</span>
                    <span className="rx-pcard__meta">
                      <time dateTime={x.date}>{bgDate(x.date)}</time>
                    </span>
                    <span className="rx-pcard__t">{x.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </section>
      ) : null}
      <CtaBand />
    </PageShell>
  );
}
