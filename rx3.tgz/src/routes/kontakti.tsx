import { createFileRoute } from "@tanstack/react-router";

import { MapEmbed } from "@/components/site/areas";
import { SocialLinks } from "@/components/site/chrome";
import { ADDRESS, BRAND, EMAIL, PHONE_MOBILE, PHONE_OFFICE, SITE_URL } from "@/components/site/data";
import { crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";
import { Contact } from "@/components/site/sections";

const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "Контакти", href: "/kontakti" },
];

export const Route = createFileRoute("/kontakti")({
  head: () =>
    pageHead({
      title: "Контакти | Рефлекс М — фирма за почистване в София",
      description: `${BRAND}: ${ADDRESS.full}. Телефон ${PHONE_MOBILE.label} и ${PHONE_OFFICE.label}, имейл ${EMAIL}. Заявете безплатен оглед.`,
      path: "/kontakti",
      schema: [crumbsLd(CRUMBS), { "@type": "ContactPage", name: `Контакти — ${BRAND}`, url: `${SITE_URL}/kontakti`, about: { "@id": `${SITE_URL}/#business` } }],
    }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <PageShell>
      <PageHead crumbs={CRUMBS} eyebrow="Контакти" title={`Контакти на ${BRAND}`}>
        <div className="rx-cgrid">
          <a className="rx-cbox" href={PHONE_MOBILE.href}>
            <span>Мобилен</span>
            <strong>{PHONE_MOBILE.label}</strong>
          </a>
          <a className="rx-cbox" href={PHONE_OFFICE.href}>
            <span>Офис</span>
            <strong>{PHONE_OFFICE.label}</strong>
          </a>
          <a className="rx-cbox" href={`mailto:${EMAIL}`}>
            <span>Имейл</span>
            <strong>{EMAIL}</strong>
          </a>
          <div className="rx-cbox">
            <span>Адрес</span>
            <strong>{ADDRESS.full}</strong>
          </div>
        </div>
        <SocialLinks className="rx-social rx-cbox__social" />
      </PageHead>
      <section className="rx-wrap rx-cmap" aria-label="Карта">
        <MapEmbed />
      </section>
      <Contact />
    </PageShell>
  );
}
