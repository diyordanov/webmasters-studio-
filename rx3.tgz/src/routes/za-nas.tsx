import { createFileRoute } from "@tanstack/react-router";

import { BRAND, LEGAL_NAME, RATING, SITE_URL } from "@/components/site/data";
import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";
import { Picture, type Img } from "@/components/site/prose";
import { VideoGrid, type Video } from "@/components/site/video-grid";
import about from "../content/about.json";

const A = about as { images: Img[]; logos: { src: string; w: number; h: number; name: string }[]; testimonials: Video[]; media: Video[] };

const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "За нас", href: "/za-nas" },
];

const VALUES = [
  {
    t: "Екип",
    d: "Подхождаме прецизно във всички етапи на услугата — от първата среща с клиента до блестящия краен резултат. Освен чисти пространства, осигуряваме и чисти взаимоотношения.",
  },
  {
    t: "Качество",
    d: "Работим с висококачествено оборудване и препарати. Служителите ни преминават обучение за работа с клиенти, техническа квалификация и тренинг за професионално почистване.",
  },
  {
    t: "Правилният избор",
    d: "В бизнес сгради, магазини, офиси, складове, производствени помещения и във вашия дом почистват професионалисти с изрядно работно облекло и качествена техника.",
  },
];

export const Route = createFileRoute("/za-nas")({
  head: () =>
    pageHead({
      title: "За нас — Рефлекс М, фирма за почистване в София",
      description:
        "Рефлекс М извършва абонаментно и основно почистване на офиси и домове и почистване след ремонт в София от 2012 г. Екип, качество, клиенти и медийни участия.",
      path: "/za-nas",
      schema: [crumbsLd(CRUMBS), { "@type": "AboutPage", name: `За ${BRAND}`, url: `${SITE_URL}/za-nas`, about: { "@id": `${SITE_URL}/#business` } }],
    }),
  component: AboutPage,
});

function AboutPage() {
  const [main, ...rest] = A.images;
  return (
    <PageShell>
      <PageHead
        crumbs={CRUMBS}
        eyebrow="За нас"
        title={`За ${BRAND}`}
        lead={`${BRAND} извършва абонаментно и основно почистване на офиси и домове и почистване след ремонт по нови стандарти за качество, техника и обслужване. Създателите на фирмата имат дългогодишен международен опит в управлението и поддръжката на различни типове сгради и прилагат европейските и световните практики в бранша.`}
      />
      <section className="rx-wrap rx-about">
        {main ? (
          <div className="rx-about__media">
            <Picture img={main} alt={`Екипът на ${BRAND}`} eager sizes="(max-width: 860px) 92vw, 640px" />
          </div>
        ) : null}
        <dl className="rx-stats">
          <div>
            <dt>Работим от</dt>
            <dd>2012</dd>
          </div>
          <div>
            <dt>Оценка в Google</dt>
            <dd>{RATING.value}★</dd>
          </div>
          <div>
            <dt>Отзиви в Google</dt>
            <dd>{RATING.count}</dd>
          </div>
          <div>
            <dt>Фирма</dt>
            <dd className="rx-stats__s">{LEGAL_NAME}</dd>
          </div>
        </dl>
      </section>
      <section className="rx-section rx-dark" aria-labelledby="rx-values-h">
        <div className="rx-wrap">
          <h2 id="rx-values-h" className="rx-h2">
            Повече от чисто
          </h2>
          <ol className="rx-steps rx-values">
            {VALUES.map((v, i) => (
              <li key={v.t} className="rx-step">
                <span className="rx-step__n">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="rx-h3">{v.t}</h3>
                <p>{v.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>
      {rest.length ? (
        <section className="rx-wrap rx-about__strip" aria-label="Снимки от работата ни">
          {rest.map((im, i) => (
            <Picture key={i} img={im} alt={`${BRAND} на обект`} sizes="(max-width: 860px) 46vw, 300px" />
          ))}
        </section>
      ) : null}
      <section className="rx-section" aria-labelledby="rx-clients2-h">
        <div className="rx-wrap">
          <div className="rx-head">
            <p className="rx-eyebrow">Клиенти</p>
            <h2 id="rx-clients2-h" className="rx-h2">
              Нашите клиенти
            </h2>
            <p className="rx-lead">Компании и институции, които поверяват почистването на {BRAND}.</p>
          </div>
          <ul className="rx-logogrid">
            {A.logos.map((l) => (
              <li key={l.src}>
                <img src={l.src} alt={l.name} width={l.w} height={l.h} loading="lazy" decoding="async" />
              </li>
            ))}
          </ul>
        </div>
      </section>
      <section className="rx-section rx-reviews" aria-labelledby="rx-testi-h">
        <div className="rx-wrap">
          <div className="rx-head">
            <p className="rx-eyebrow">Отзиви</p>
            <h2 id="rx-testi-h" className="rx-h2">
              Мнения от дългогодишни партньори
            </h2>
          </div>
          <VideoGrid videos={A.testimonials} />
        </div>
      </section>
      {A.media.length ? (
        <section className="rx-section" aria-labelledby="rx-media-h">
          <div className="rx-wrap">
            <div className="rx-head">
              <p className="rx-eyebrow">Медии</p>
              <h2 id="rx-media-h" className="rx-h2">
                Медиите за нас
              </h2>
            </div>
            <VideoGrid videos={A.media} />
          </div>
        </section>
      ) : null}
      <CtaBand />
    </PageShell>
  );
}
