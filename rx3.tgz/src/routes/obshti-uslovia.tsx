import { createFileRoute } from "@tanstack/react-router";

import { legalHead, LegalPage } from "@/components/site/legal";

export const Route = createFileRoute("/obshti-uslovia")({
  head: () => legalHead("terms"),
  component: () => <LegalPage k="terms" />,
});
