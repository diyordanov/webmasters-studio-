import { createFileRoute } from "@tanstack/react-router";

import { PhoneIcon } from "@/components/site/chrome";
import { BRAND, PHONE_MOBILE } from "@/components/site/data";
import { CtaBand, crumbsLd, pageHead, PageHead, PageShell } from "@/components/site/page";
import { PriceTable } from "@/components/site/price-table";
import { INDIVIDUAL, PRICE_NOTES, PRICES } from "@/components/site/prices";

const CRUMBS = [
  { name: "Начало", href: "/" },
  { name: "Цени", href: "/ceni" },
];

export const Route = createFileRoute("/ceni")({
  head: () =>
    pageHead({
      title: "Цени за почистване в София | Рефлекс М",
      description:
        "Цени за почистване в София: пране на дивани от 41 €, матраци от 51 €, миене на стъкла от 1,28 €/кв.м, почистване на баня 75,15 €. Безплатен оглед и оферта с крайна цена.",
      path: "/ceni",
      schema: [crumbsLd(CRUMBS)],
    }),
  component: PricesPage,
});

function PricesPage() {
  return (
    <PageShell>
      <PageHead
        crumbs={CRUMBS}
        eyebrow="Цени"
        title="Цени за почистване в София"
        lead={`Ценоразписът на ${BRAND} за най-търсените услуги. За офиси, домове, входове и обекти след ремонт цената се изчислява след безплатен оглед според площта и степента на замърсяване.`}
      />
      <section className="rx-wrap rx-prices-page" aria-label="Ценоразпис">
        <div className="rx-prices-page__tables">
          {PRICES.map((g) => (
            <PriceTable key={g.id} group={g} />
          ))}
        </div>
        <aside className="rx-prices-page__side">
          <div className="rx-ctacard">
            <p className="rx-ctacard__k">Индивидуални цени</p>
            <p className="rx-ctacard__t">Оферта след безплатен оглед при:</p>
            <ul className="rx-ticks">
              {INDIVIDUAL.map((x) => (
                <li key={x}>{x}</li>
              ))}
            </ul>
            <a className="rx-btn rx-btn--primary" href={PHONE_MOBILE.href}>
              <PhoneIcon /> {PHONE_MOBILE.label}
            </a>
            <a className="rx-btn rx-btn--ghost" href="/kontakti">
              Изпратете запитване
            </a>
          </div>
          <ul className="rx-notes">
            {PRICE_NOTES.map((n) => (
              <li key={n}>{n}</li>
            ))}
          </ul>
        </aside>
      </section>
      <section className="rx-section rx-wrap rx-prose-wrap" aria-labelledby="rx-why-h">
        <div className="rx-prose">
          <h2 id="rx-why-h">Как се формира цената за почистване</h2>
          <p>
            Ценоразписът ни е гъвкав и в повечето случаи крайната цена се изчислява индивидуално — на база почистената площ и
            степента на замърсяване. Така плащате за реалния обем работа, както при частните, така и при корпоративните
            клиенти.
          </p>
          <p>
            При абонаментно почистване на офиси и входове цената се договаря на месец според честотата и обхвата на услугата.
            При основно почистване и почистване след ремонт огледът на място ни позволява да дадем точна оферта, която не се
            променя в деня на почистването.
          </p>
        </div>
      </section>
      <CtaBand />
    </PageShell>
  );
}
